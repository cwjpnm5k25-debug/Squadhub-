# Poto — la messagerie de tes potes 💬

Poto est une messagerie de groupe **mobile-first** : on crée un compte, on ouvre un serveur,
on partage un code d'invitation et on discute en direct. Tout est stocké côté serveur
(PostgreSQL), donc les messages suivent les utilisateurs d'un appareil à l'autre.

## Stack

- **Next.js 16** (App Router, React 19, TypeScript) — UI + API routes
- **PostgreSQL** + **Drizzle ORM** — comptes, sessions, serveurs, salons, messages
- **Tailwind CSS 4** — thème sombre, interface pensée mobile d'abord
- Sessions sécurisées : mot de passe haché avec **scrypt**, cookie `httpOnly`
- Temps réel : polling HTTP toutes les 2,5 s (compatible 100 % Vercel / serverless, pas de
  WebSocket à héberger)

## Fonctionnalités

- Inscription / connexion / déconnexion
- Serveurs (création, découverte publique, code d'invitation à 6 caractères, lien d'invitation)
- Salons illimités par serveur (`#général`, `#memes`, …)
- Messages en direct avec envoi optimiste, indicateur « envoi… » et avatars
- Liste des membres avec présence en ligne (heartbeat)
- Interface installable sur l'écran d'accueil (manifest PWA)
- Serveur public de démo auto-créé, code **`POTO`**

## Lancer en local

```bash
npm install
# .env contient DATABASE_URL=postgresql://...
npx drizzle-kit push     # crée les tables
npm run dev              # http://localhost:3000
```

Variables d'environnement attendues :

```
DATABASE_URL=postgresql://user:password@host:5432/database
```

## Publier sur GitHub + Vercel (gratuit)

1. **GitHub** : crée un dépôt vide, puis dans le projet :
   ```bash
   git init
   git add .
   git commit -m "Poto - messagerie"
   git branch -M main
   git remote add origin https://github.com/<ton-compte>/<ton-repo>.git
   git push -u origin main
   ```
2. **Base PostgreSQL gratuite** : crée un projet sur [Neon](https://neon.tech) (ou Vercel
   Postgres / Supabase) et copie la chaîne `postgresql://…` fournie.
3. **Vercel** : [vercel.com/new](https://vercel.com/new) → importe le dépôt GitHub.
   - Framework : Next.js (détecté automatiquement)
   - Ajoute la variable d'environnement `DATABASE_URL` (Production + Preview)
   - Clique sur **Deploy**
4. **Créer les tables** une fois la base prête, depuis ta machine :
   ```bash
   DATABASE_URL="postgresql://…" npx drizzle-kit push
   ```
   (adapté la commande : `npx drizzle-kit push` lit `drizzle.config.json`, remplace l'URL
   locale par celle de Neon si besoin)
5. Ouvre ton URL `https://ton-projet.vercel.app`, crée un compte et partage le code
   d'invitation à tes potes.

> Astuce : les cookies de session sont automatiquement `secure` en production (HTTPS Vercel),
> aucune configuration supplémentaire n'est nécessaire.

## Structure

```
src/app/                 pages (accueil, connexion, inscription, /app) + API routes
src/components/          UI du chat, formulaires d'auth
src/db/                  schéma Drizzle et client PostgreSQL
src/lib/                 auth (scrypt/sessions), requêtes chat, types, utilitaires UI
```
