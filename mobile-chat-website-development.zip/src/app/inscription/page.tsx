import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { AuthForm } from "@/components/auth-form";
import { getCurrentUser } from "@/lib/auth";

export const metadata: Metadata = { title: "Créer un compte — Poto" };
export const dynamic = "force-dynamic";

export default async function RegisterPage({
  searchParams,
}: {
  searchParams: Promise<{ invite?: string; next?: string }>;
}) {
  const user = await getCurrentUser();
  const params = await searchParams;
  const invite = params.invite?.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 12) || undefined;
  const redirectTo = invite
    ? `/app?invite=${invite}`
    : params.next && params.next.startsWith("/")
      ? params.next
      : "/app";

  if (user) redirect(redirectTo);

  return (
    <div className="relative min-h-[100dvh] bg-ink lg:grid lg:grid-cols-[1fr_1.1fr]">
      <div className="pointer-events-none absolute inset-0 mesh opacity-50 lg:hidden" />
      <div className="relative z-10 flex items-center justify-between px-5 py-5 lg:hidden">
        <Link href="/" className="flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brand to-pink text-base">
            💬
          </span>
          <span className="text-lg font-black">Poto</span>
        </Link>
        <Link
          href="/connexion"
          className="rounded-full border border-white/15 bg-white/5 px-4 py-2 text-xs font-semibold transition hover:bg-white/10"
        >
          Connexion
        </Link>
      </div>

      <div className="relative z-10 flex flex-col justify-between overflow-hidden bg-gradient-to-br from-brand/25 via-purple-700/20 to-pink/20 p-10">
        <Link href="/" className="hidden items-center gap-2.5 lg:flex">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-brand to-pink text-lg">
            💬
          </span>
          <span className="text-xl font-black">Poto</span>
        </Link>
        <div className="hidden lg:block">
          <h2 className="text-balance text-4xl font-black leading-tight tracking-tight">
            Un compte, un serveur, et tes potes rappliquent.
          </h2>
          <ul className="mt-7 space-y-4 text-sm">
            {[
              "Un serveur public offert à l'inscription",
              "Des salons illimités (#général, #memes, #musique…)",
              "Invitations par code à 6 caractères",
              "Messages en direct, sur mobile comme sur ordi",
            ].map((item) => (
              <li key={item} className="flex items-start gap-3">
                <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-mint/20 text-[11px] text-mint">
                  ✓
                </span>
                <span className="text-white/85">{item}</span>
              </li>
            ))}
          </ul>
        </div>
        <p className="hidden text-xs text-white/60 lg:block">
          Gratuit, sans publicité. Hébergeable sur Vercel en quelques minutes.
        </p>
      </div>

      <div className="relative z-10 flex items-center justify-center px-5 py-10 lg:bg-ink lg:px-10">
        <div className="w-full max-w-md rounded-[1.8rem] border border-white/10 bg-panel/85 p-6 shadow-2xl shadow-black/50 backdrop-blur sm:p-8">
          <AuthForm mode="register" redirectTo={redirectTo} presetInvite={invite} />
        </div>
      </div>
    </div>
  );
}
