import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { ChatApp } from "@/components/chat-app";
import { getCurrentUser } from "@/lib/auth";
import { ensureDemoServer } from "@/lib/chat";

export const metadata: Metadata = { title: "Mes salons — Poto" };
export const dynamic = "force-dynamic";

export default async function AppPage({
  searchParams,
}: {
  searchParams: Promise<{ invite?: string }>;
}) {
  const user = await getCurrentUser();
  const params = await searchParams;
  const invite = params.invite?.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 12) || undefined;

  if (!user) {
    redirect(invite ? `/connexion?invite=${invite}` : "/connexion");
  }

  await ensureDemoServer().catch(() => undefined);

  return <ChatApp initialUser={user} initialInvite={invite} />;
}
