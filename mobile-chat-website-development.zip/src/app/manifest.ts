import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Poto — la messagerie de tes potes",
    short_name: "Poto",
    description:
      "Crée un serveur, partage le code d'invitation et discute en direct avec tes potes.",
    start_url: "/app",
    display: "standalone",
    background_color: "#08080f",
    theme_color: "#08080f",
    orientation: "portrait",
    lang: "fr",
    icons: [
      {
        src: "/icon.svg",
        sizes: "any",
        type: "image/svg+xml",
        purpose: "any",
      },
      {
        src: "/icon-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/icon-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "maskable",
      },
    ],
  };
}
