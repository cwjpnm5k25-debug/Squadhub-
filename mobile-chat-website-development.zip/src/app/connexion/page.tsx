import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { AuthForm } from "@/components/auth-form";
import { getCurrentUser } from "@/lib/auth";

export const metadata: Metadata = { title: "Connexion — Poto" };
export const dynamic = "force-dynamic";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ invite?: string; next?: string }>;
}) {
  const user = await getCurrentUser();
  const params = await searchParams;
  const invite = params.invite?.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 12) || undefined;
  const redirectTo = invite
    ? `/app?invite=${invite}`
    : params.next && params.next.startsWith("/")
      ? params.next
      : "/app";

  if (user) redirect(redirectTo);

  return (
    <div className="relative flex min-h-[100dvh] flex-col bg-ink">
      <div className="pointer-events-none absolute inset-0 mesh opacity-50" />
      <div className="relative z-10 flex items-center justify-between px-5 py-5 sm:px-8">
        <Link href="/" className="flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brand to-pink text-base">
            💬
          </span>
          <span className="text-lg font-black">Poto</span>
        </Link>
        <Link
          href="/inscription"
          className="rounded-full border border-white/15 bg-white/5 px-4 py-2 text-xs font-semibold transition hover:bg-white/10"
        >
          Créer un compte
        </Link>
      </div>

      <div className="relative z-10 mx-auto flex w-full max-w-md flex-1 items-center px-5 pb-14 sm:px-0">
        <div className="w-full rounded-[1.8rem] border border-white/10 bg-panel/85 p-6 shadow-2xl shadow-black/50 backdrop-blur sm:p-8">
          <AuthForm mode="login" redirectTo={redirectTo} presetInvite={invite} />
        </div>
      </div>
    </div>
  );
}
