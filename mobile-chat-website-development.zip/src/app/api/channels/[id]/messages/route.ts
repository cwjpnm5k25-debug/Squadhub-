import { touchUser } from "@/lib/auth";
import { getChannelMessages, postMessage } from "@/lib/chat";
import { jsonError, parseId, readJson, requireUser, stringField } from "@/lib/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireUser();
  if (auth.response) return auth.response;

  const { id } = await ctx.params;
  const channelId = parseId(id);
  if (!channelId) return jsonError("Salon introuvable.", 404);

  const afterRaw = new URL(request.url).searchParams.get("after");
  const after = afterRaw ? Number(afterRaw) : undefined;

  const result = await getChannelMessages(
    auth.user.id,
    channelId,
    Number.isFinite(after) && (after ?? 0) > 0 ? after : undefined,
  );

  if (!result) return jsonError("Tu n'as pas accès à ce salon.", 403);

  return Response.json(result);
}

export async function POST(request: Request, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireUser();
  if (auth.response) return auth.response;

  const { id } = await ctx.params;
  const channelId = parseId(id);
  if (!channelId) return jsonError("Salon introuvable.", 404);

  const body = await readJson(request);
  const content = stringField(body, "content", 2000);

  if (!content) return jsonError("Ton message est vide.");
  if (content.length > 2000) return jsonError("Message trop long (2000 caractères max).");

  const message = await postMessage(auth.user.id, channelId, content);
  if (!message) return jsonError("Tu n'as pas accès à ce salon.", 403);

  await touchUser(auth.user.id);

  return Response.json({ message }, { status: 201 });
}
