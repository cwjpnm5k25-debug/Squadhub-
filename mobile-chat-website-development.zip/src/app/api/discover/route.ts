import { getCurrentUser } from "@/lib/auth";
import { ensureDemoServer, getPublicServers } from "@/lib/chat";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  await ensureDemoServer();
  const user = await getCurrentUser();
  const servers = await getPublicServers(user?.id ?? null);
  return Response.json({ servers });
}
