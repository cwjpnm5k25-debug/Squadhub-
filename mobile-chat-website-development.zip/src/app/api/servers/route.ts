import { jsonError, readJson, requireUser, stringField } from "@/lib/http";
import { createServerForUser } from "@/lib/chat";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const auth = await requireUser();
  if (auth.response) return auth.response;

  const body = await readJson(request);
  const name = stringField(body, "name", 40);
  const emoji = stringField(body, "emoji", 8) || "💬";
  const description = stringField(body, "description", 160);
  const isPublic = body.isPublic === true;

  if (name.length < 2) {
    return jsonError("Donne un nom d'au moins 2 caractères à ton serveur.");
  }

  const created = await createServerForUser({
    userId: auth.user.id,
    name,
    emoji,
    description: description || undefined,
    isPublic,
  });

  return Response.json(created, { status: 201 });
}
