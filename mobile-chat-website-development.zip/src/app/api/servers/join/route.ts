import { jsonError, readJson, requireUser, stringField } from "@/lib/http";
import { joinServerByCode } from "@/lib/chat";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const auth = await requireUser();
  if (auth.response) return auth.response;

  const body = await readJson(request);
  const code = stringField(body, "code", 20);

  if (!code) {
    return jsonError("Entre un code d'invitation.");
  }

  const result = await joinServerByCode(auth.user.id, code);
  if (!result) {
    return jsonError("Aucun serveur ne correspond à ce code. Vérifie auprès de ton pote.", 404);
  }

  return Response.json(result);
}
