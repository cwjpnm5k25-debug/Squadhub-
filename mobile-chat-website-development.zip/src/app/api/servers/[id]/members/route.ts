import { getServerMembers } from "@/lib/chat";
import { jsonError, parseId, requireUser } from "@/lib/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(_request: Request, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireUser();
  if (auth.response) return auth.response;

  const { id } = await ctx.params;
  const serverId = parseId(id);
  if (!serverId) return jsonError("Serveur introuvable.", 404);

  const members = await getServerMembers(auth.user.id, serverId);
  if (!members) return jsonError("Tu n'as pas accès à ce serveur.", 403);

  return Response.json({ members });
}
