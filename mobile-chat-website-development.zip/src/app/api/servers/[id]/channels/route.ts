import { createChannel } from "@/lib/chat";
import { jsonError, parseId, readJson, requireUser, stringField } from "@/lib/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireUser();
  if (auth.response) return auth.response;

  const { id } = await ctx.params;
  const serverId = parseId(id);
  if (!serverId) return jsonError("Serveur introuvable.", 404);

  const body = await readJson(request);
  const name = stringField(body, "name", 30);
  if (name.length < 2) {
    return jsonError("Le nom du salon doit faire au moins 2 caractères.");
  }

  const channelId = await createChannel(auth.user.id, serverId, name);
  if (!channelId) {
    return jsonError("Impossible de créer ce salon (nom invalide ou accès refusé).", 400);
  }

  return Response.json({ channelId }, { status: 201 });
}
