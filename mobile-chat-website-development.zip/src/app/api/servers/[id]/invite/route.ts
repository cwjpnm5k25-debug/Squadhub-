import { regenerateInviteCode } from "@/lib/chat";
import { jsonError, parseId, requireUser } from "@/lib/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(_request: Request, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireUser();
  if (auth.response) return auth.response;

  const { id } = await ctx.params;
  const serverId = parseId(id);
  if (!serverId) return jsonError("Serveur introuvable.", 404);

  const code = await regenerateInviteCode(auth.user.id, serverId);
  if (!code) {
    return jsonError("Seul le créateur du serveur peut changer le code.", 403);
  }

  return Response.json({ inviteCode: code });
}
