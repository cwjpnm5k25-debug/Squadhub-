import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, normalizeUsername, touchUser, verifyPassword } from "@/lib/auth";
import { jsonError, publicUser, readJson, stringField } from "@/lib/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = await readJson(request);
  const username = normalizeUsername(stringField(body, "username", 32));
  const password = typeof body.password === "string" ? body.password : "";

  if (!username || !password) {
    return jsonError("Renseigne ton pseudo et ton mot de passe.");
  }

  const [user] = await db
    .select({
      id: users.id,
      username: users.username,
      displayName: users.displayName,
      passwordHash: users.passwordHash,
    })
    .from(users)
    .where(eq(users.username, username))
    .limit(1);

  if (!user || !(await verifyPassword(password, user.passwordHash))) {
    return jsonError("Pseudo ou mot de passe incorrect.", 401);
  }

  await createSession(user.id);
  await touchUser(user.id);

  return Response.json({ user: publicUser(user) });
}
