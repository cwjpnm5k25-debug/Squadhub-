import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import {
  createSession,
  displayNameError,
  hashPassword,
  normalizeUsername,
  passwordError,
  usernameError,
} from "@/lib/auth";
import { jsonError, publicUser, readJson, stringField } from "@/lib/http";
import { DEMO_INVITE_CODE, ensureDemoServer, joinServerByCode } from "@/lib/chat";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = await readJson(request);
  const displayName = stringField(body, "displayName", 32);
  const username = normalizeUsername(stringField(body, "username", 32));
  const password = typeof body.password === "string" ? body.password : "";

  const nameIssue = displayNameError(displayName);
  if (nameIssue) return jsonError(nameIssue);

  const usernameIssue = usernameError(username);
  if (usernameIssue) return jsonError(usernameIssue);

  const passwordIssue = passwordError(password);
  if (passwordIssue) return jsonError(passwordIssue);

  const existing = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.username, username))
    .limit(1);

  if (existing.length > 0) {
    return jsonError("Ce pseudo est déjà pris. Essaie un autre @pseudo.", 409);
  }

  try {
    const passwordHash = await hashPassword(password);
    const [created] = await db
      .insert(users)
      .values({ username, displayName, passwordHash })
      .returning({ id: users.id, username: users.username, displayName: users.displayName });

    await createSession(created.id);

    // On offre un premier serveur vivant à chaque nouveau compte.
    await ensureDemoServer();
    await joinServerByCode(created.id, DEMO_INVITE_CODE).catch(() => null);

    return Response.json({ user: publicUser(created) }, { status: 201 });
  } catch {
    return jsonError("Impossible de créer le compte pour le moment. Réessaie.", 500);
  }
}
