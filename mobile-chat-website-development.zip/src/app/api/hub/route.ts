import { touchUser } from "@/lib/auth";
import { DEMO_INVITE_CODE, ensureDemoServer, getHub } from "@/lib/chat";
import { publicUser, requireUser } from "@/lib/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireUser();
  if (auth.response) return auth.response;

  await touchUser(auth.user.id);
  await ensureDemoServer();

  const hub = await getHub(auth.user.id);
  return Response.json({ user: publicUser(auth.user), ...hub, demoCode: DEMO_INVITE_CODE });
}
