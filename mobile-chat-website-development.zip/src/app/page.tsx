import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";
import { DEMO_INVITE_CODE, ensureDemoServer, getPlatformStats, getPublicServers } from "@/lib/chat";

export const dynamic = "force-dynamic";

const steps = [
  {
    emoji: "🪪",
    title: "Crée ton compte",
    text: "Un pseudo, un mot de passe, et c'est parti. Quinze secondes, pas de carte bancaire.",
  },
  {
    emoji: "🔥",
    title: "Ouvre ton serveur",
    text: "Donne-lui un nom, un emoji. Les salons #général et #blabla sont créés automatiquement.",
  },
  {
    emoji: "🎟️",
    title: "File le code à tes potes",
    text: "Un code à 6 caractères (ou un lien). Ils le tapent, ils sont dans le salon avec toi.",
  },
];

const features = [
  {
    emoji: "⚡",
    title: "Messages en direct",
    text: "Les nouveaux messages arrivent tout seuls en quelques secondes, sans recharger la page.",
  },
  {
    emoji: "📱",
    title: "Pensé mobile d'abord",
    text: "Plein écran, gros boutons, zones sûres iOS. Installable sur l'écran d'accueil comme une app.",
  },
  {
    emoji: "🔒",
    title: "Comptes sécurisés",
    text: "Mots de passe chiffrés avec scrypt, sessions en cookie httpOnly. Personne ne lit tes secrets.",
  },
  {
    emoji: "👥",
    title: "Qui est en ligne",
    text: "Le point vert te dit qui est connecté. Tu sais toujours qui peut répondre maintenant.",
  },
  {
    emoji: "🗂️",
    title: "Autant de salons que tu veux",
    text: "#général, #memes, #musique, #entraide… Crée des salons pour chaque délire.",
  },
  {
    emoji: "☁️",
    title: "De vrais serveurs",
    text: "Tout est stocké côté serveur (PostgreSQL) : tes messages te suivent d'un appareil à l'autre.",
  },
];

export default async function LandingPage() {
  await ensureDemoServer().catch(() => undefined);
  const user = await getCurrentUser();
  const [stats, publicServers] = await Promise.all([
    getPlatformStats(),
    getPublicServers(user?.id ?? null),
  ]);

  const startHref = user ? "/app" : "/inscription";
  const authHref = user ? "/app" : "/connexion";
  const joinHref = (code: string) =>
    user ? `/app?invite=${code}` : `/inscription?invite=${code}`;

  return (
    <div className="relative min-h-[100dvh] overflow-x-hidden bg-ink">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[820px] mesh opacity-70" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[820px] grid-lines opacity-[0.35]" />

      <header className="relative z-20 mx-auto flex w-full max-w-6xl items-center justify-between px-5 py-5 sm:px-8">
        <Link href="/" className="flex items-center gap-2.5">
          <span className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-brand via-purple-500 to-pink text-lg shadow-lg shadow-brand/30">
            💬
          </span>
          <span className="text-xl font-black tracking-tight">Poto</span>
        </Link>
        <nav className="hidden items-center gap-7 text-sm font-medium text-muted md:flex">
          <a className="transition hover:text-white" href="#comment">
            Comment ça marche
          </a>
          <a className="transition hover:text-white" href="#fonctionnalites">
            Fonctionnalités
          </a>
          <a className="transition hover:text-white" href="#serveurs">
            Serveurs publics
          </a>
          <a className="transition hover:text-white" href="#publier">
            Mettre en ligne
          </a>
        </nav>
        <div className="flex items-center gap-2">
          <Link
            href={authHref}
            className="hidden rounded-full px-4 py-2 text-sm font-semibold text-muted transition hover:text-white sm:block"
          >
            {user ? "Mon espace" : "Connexion"}
          </Link>
          <Link
            href={startHref}
            className="rounded-full bg-white px-4 py-2.5 text-sm font-bold text-ink transition hover:bg-white/90"
          >
            {user ? "Ouvrir Poto" : "Créer un compte"}
          </Link>
        </div>
      </header>

      <main className="relative z-10">
        <section className="mx-auto grid w-full max-w-6xl items-center gap-14 px-5 pt-10 pb-16 sm:px-8 lg:grid-cols-[1.05fr_0.95fr] lg:pt-16">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 text-xs font-semibold text-lemon backdrop-blur">
              <span className="h-1.5 w-1.5 rounded-full bg-mint" />
              Gratuit · sans pub · fait pour le mobile
            </span>
            <h1 className="mt-6 text-balance text-[2.6rem] leading-[1.05] font-black tracking-tight sm:text-6xl">
              Tes potes ont enfin{" "}
              <span className="bg-gradient-to-r from-brand-soft via-pink to-lemon bg-clip-text text-transparent">
                leur messagerie
              </span>
              .
            </h1>
            <p className="mt-5 max-w-xl text-base leading-relaxed text-muted sm:text-lg">
              Crée ton compte, ouvre ton serveur, envoie le code d&apos;invitation. Vos salons sont
              en ligne immédiatement — sur ton téléphone comme sur l&apos;ordi. Pas d&apos;app à
              installer, pas de numéro de téléphone à donner.
            </p>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link
                href={startHref}
                className="group inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-brand to-pink px-6 py-4 text-base font-bold shadow-xl shadow-brand/25 transition hover:brightness-110"
              >
                {user ? "Retour dans mes salons" : "Créer mon compte — c'est gratuit"}
                <span className="transition group-hover:translate-x-0.5">→</span>
              </Link>
              <Link
                href={joinHref(DEMO_INVITE_CODE)}
                className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/15 bg-white/5 px-6 py-4 text-base font-semibold backdrop-blur transition hover:bg-white/10"
              >
                🎟️ Rejoindre avec un code
              </Link>
            </div>

            <div className="mt-9 grid max-w-md grid-cols-3 gap-3 text-center">
              {[
                { value: stats.users, label: "potes inscrits" },
                { value: stats.servers, label: "serveurs créés" },
                { value: stats.messages, label: "messages envoyés" },
              ].map((stat) => (
                <div
                  key={stat.label}
                  className="rounded-2xl border border-white/10 bg-white/[0.04] px-3 py-3 backdrop-blur"
                >
                  <p className="text-2xl font-black text-white">{stat.value}</p>
                  <p className="mt-0.5 text-[11px] font-medium text-muted">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="relative mx-auto w-full max-w-[340px] animate-floaty lg:max-w-[360px]">
            <div className="absolute -inset-6 rounded-[3rem] bg-gradient-to-br from-brand/40 via-pink/20 to-mint/20 blur-2xl" />
            <div className="relative overflow-hidden rounded-[2.4rem] border border-white/15 bg-panel/95 shadow-2xl shadow-black/60 backdrop-blur">
              <div className="flex items-center gap-3 border-b border-line/70 px-4 py-3.5">
                <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-orange-400 to-pink text-base">
                  🔥
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-bold">Le QG des potes</p>
                  <p className="flex items-center gap-1.5 text-[11px] text-muted">
                    <span className="h-1.5 w-1.5 rounded-full bg-mint" /> 5 en ligne · #général
                  </p>
                </div>
                <span className="rounded-lg bg-white/5 px-2 py-1 text-[10px] font-bold tracking-wide text-lemon">
                  POTO
                </span>
              </div>
              <div className="space-y-3 px-4 py-4">
                <p className="text-center text-[10px] font-semibold tracking-widest text-muted uppercase">
                  Aujourd&apos;hui
                </p>
                {[
                  {
                    name: "Léa",
                    color: "from-pink-500 to-orange-400",
                    text: "On se retrouve ce soir sur le serveur ? 🔥",
                    mine: false,
                  },
                  {
                    name: "Sam",
                    color: "from-emerald-400 to-cyan-500",
                    text: "Grave ! J'ai créé le salon #memes",
                    mine: false,
                  },
                  {
                    name: "Toi",
                    color: "from-violet-500 to-fuchsia-500",
                    text: "J'arrive, je finis juste de publier le site 😎",
                    mine: true,
                  },
                ].map((message) => (
                  <div
                    key={message.name}
                    className={`flex items-end gap-2 ${message.mine ? "flex-row-reverse" : ""}`}
                  >
                    <div
                      className={`grid h-7 w-7 shrink-0 place-items-center rounded-full bg-gradient-to-br ${message.color} text-[10px] font-bold`}
                    >
                      {message.name.slice(0, 1)}
                    </div>
                    <div className={`max-w-[78%] ${message.mine ? "text-right" : ""}`}>
                      <p className="mb-1 text-[10px] font-semibold text-muted">{message.name}</p>
                      <p
                        className={`rounded-2xl px-3 py-2 text-[12.5px] leading-snug ${
                          message.mine
                            ? "rounded-br-sm bg-gradient-to-br from-brand to-purple-600 text-white"
                            : "rounded-bl-sm bg-panel-3 text-white/90"
                        }`}
                      >
                        {message.text}
                      </p>
                    </div>
                  </div>
                ))}
                <div className="flex items-center gap-2 rounded-full border border-line bg-panel-2 px-3 py-2">
                  <span className="text-[12px] text-muted">Écris à tes potes…</span>
                  <span className="ml-auto grid h-6 w-6 place-items-center rounded-full bg-brand text-[11px]">
                    ↑
                  </span>
                </div>
              </div>
            </div>
            <div className="absolute -left-4 top-24 hidden rotate-[-6deg] rounded-xl border border-white/10 bg-panel px-3 py-2 text-xs font-semibold shadow-xl sm:block">
              <span className="mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-mint" />
              +3 potes en ligne
            </div>
            <div className="absolute -right-3 bottom-20 rotate-[5deg] rounded-xl border border-white/10 bg-panel px-3 py-2 text-xs font-semibold shadow-xl">
              🎟️ Code : <span className="text-lemon">POTO</span>
            </div>
          </div>
        </section>

        <section id="comment" className="mx-auto w-full max-w-6xl px-5 py-16 sm:px-8">
          <p className="text-xs font-bold tracking-[0.2em] text-brand-soft uppercase">
            Comment ça marche
          </p>
          <h2 className="mt-3 max-w-2xl text-balance text-3xl font-black tracking-tight sm:text-4xl">
            Ton groupe en ligne en moins d&apos;une minute.
          </h2>
          <div className="mt-9 grid gap-4 md:grid-cols-3">
            {steps.map((step, index) => (
              <div
                key={step.title}
                className="relative overflow-hidden rounded-3xl border border-white/10 bg-white/[0.035] p-6 backdrop-blur"
              >
                <span className="absolute top-4 right-5 text-5xl font-black text-white/[0.06]">
                  0{index + 1}
                </span>
                <div className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-brand/30 to-pink/20 text-2xl">
                  {step.emoji}
                </div>
                <h3 className="mt-5 text-lg font-bold">{step.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{step.text}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="fonctionnalites" className="mx-auto w-full max-w-6xl px-5 py-10 sm:px-8">
          <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <div>
              <p className="text-xs font-bold tracking-[0.2em] text-pink uppercase">
                Fonctionnalités
              </p>
              <h2 className="mt-3 max-w-xl text-balance text-3xl font-black tracking-tight sm:text-4xl">
                Tout ce qu&apos;il faut pour discuter, rien de plus.
              </h2>
            </div>
            <p className="max-w-sm text-sm text-muted">
              Pas de fil d&apos;actualité, pas d&apos;algorithme, pas de pub. Juste toi et tes
              potes.
            </p>
          </div>
          <div className="mt-9 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((feature) => (
              <div
                key={feature.title}
                className="group rounded-3xl border border-white/10 bg-panel/70 p-6 transition hover:border-brand/40 hover:bg-panel-2"
              >
                <div className="grid h-11 w-11 place-items-center rounded-xl bg-white/5 text-xl transition group-hover:scale-105">
                  {feature.emoji}
                </div>
                <h3 className="mt-4 font-bold">{feature.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{feature.text}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="serveurs" className="mx-auto w-full max-w-6xl px-5 py-16 sm:px-8">
          <div className="rounded-[2rem] border border-white/10 bg-gradient-to-br from-panel-2/90 to-panel/90 p-6 sm:p-9">
            <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
              <div>
                <p className="text-xs font-bold tracking-[0.2em] text-mint uppercase">
                  En ligne maintenant
                </p>
                <h2 className="mt-3 text-3xl font-black tracking-tight">Serveurs publics</h2>
                <p className="mt-2 max-w-lg text-sm text-muted">
                  Des serveurs ouverts à tout le monde, avec de vrais salons. Entre avec un code,
                  ou crée le tien juste après.
                </p>
              </div>
              <Link
                href={startHref}
                className="inline-flex items-center justify-center rounded-xl border border-white/15 bg-white/5 px-4 py-2.5 text-sm font-semibold transition hover:bg-white/10"
              >
                Créer mon serveur
              </Link>
            </div>

            <div className="mt-7 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {publicServers.length === 0 ? (
                <p className="text-sm text-muted">
                  Aucun serveur public pour l&apos;instant. Sois le premier : crée le tien !
                </p>
              ) : (
                publicServers.map((server) => (
                  <div
                    key={server.id}
                    className="rounded-2xl border border-white/10 bg-ink/60 p-4 transition hover:border-mint/40"
                  >
                    <div className="flex items-center gap-3">
                      <span className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-orange-400/30 to-pink/30 text-xl">
                        {server.emoji}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate font-bold">{server.name}</p>
                        <p className="flex items-center gap-1.5 text-xs text-muted">
                          <span className="h-1.5 w-1.5 rounded-full bg-mint" />
                          {server.onlineCount} en ligne · {server.memberCount} membres
                        </p>
                      </div>
                    </div>
                    {server.description ? (
                      <p className="mt-3 line-clamp-2 text-xs leading-relaxed text-muted">
                        {server.description}
                      </p>
                    ) : null}
                    <div className="mt-4 flex items-center justify-between gap-2">
                      <code className="rounded-lg bg-white/5 px-2 py-1 text-[11px] font-bold tracking-widest text-lemon">
                        {server.inviteCode}
                      </code>
                      <Link
                        href={joinHref(server.inviteCode)}
                        className="rounded-lg bg-white px-3 py-1.5 text-xs font-bold text-ink transition hover:bg-white/85"
                      >
                        {server.joined ? "Ouvrir" : "Rejoindre"}
                      </Link>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </section>

        <section id="publier" className="mx-auto w-full max-w-6xl px-5 py-10 pb-20 sm:px-8">
          <p className="text-xs font-bold tracking-[0.2em] text-lemon uppercase">Mise en ligne</p>
          <h2 className="mt-3 max-w-2xl text-balance text-3xl font-black tracking-tight sm:text-4xl">
            Ton site Poto, publié sur Vercel avec GitHub.
          </h2>
          <p className="mt-3 max-w-2xl text-sm text-muted">
            Le code est prêt : il te faut juste un dépôt GitHub, un compte Vercel et une base
            PostgreSQL gratuite (Neon ou Vercel Postgres). Le fichier{" "}
            <code className="rounded bg-white/10 px-1.5 py-0.5 text-xs">README.md</code> du projet
            détaille chaque étape.
          </p>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {[
              {
                step: "01",
                title: "Pousse sur GitHub",
                text: "Crée un dépôt, puis commit et push du projet.",
                code: "git init && git add . && git commit -m \"Poto\"",
              },
              {
                step: "02",
                title: "Base gratuite sur Neon",
                text: "Copie la chaîne de connexion PostgreSQL fournie par Neon.",
                code: "DATABASE_URL=postgresql://...",
              },
              {
                step: "03",
                title: "Importe sur Vercel",
                text: "Ajoute DATABASE_URL dans les variables d'environnement, puis Deploy.",
                code: "npx drizzle-kit push",
              },
            ].map((card) => (
              <div
                key={card.step}
                className="rounded-3xl border border-white/10 bg-white/[0.035] p-6 backdrop-blur"
              >
                <p className="text-xs font-black tracking-widest text-brand-soft">{card.step}</p>
                <h3 className="mt-2 font-bold">{card.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{card.text}</p>
                <pre className="mt-4 overflow-x-auto rounded-xl border border-white/10 bg-ink/80 p-3 text-[11px] text-mint">
                  <code>{card.code}</code>
                </pre>
              </div>
            ))}
          </div>
        </section>

        <section className="mx-auto w-full max-w-6xl px-5 pb-20 sm:px-8">
          <div className="relative overflow-hidden rounded-[2.2rem] border border-white/15 bg-gradient-to-br from-brand via-purple-600 to-pink p-8 text-center shadow-2xl shadow-brand/30 sm:p-14">
            <div className="absolute -top-16 -right-10 h-48 w-48 rounded-full bg-white/20 blur-3xl" />
            <h2 className="relative text-balance text-3xl font-black tracking-tight sm:text-4xl">
              Allez, on arrête de se perdre entre 4 applis.
            </h2>
            <p className="relative mx-auto mt-3 max-w-xl text-sm text-white/85 sm:text-base">
              Crée ton compte en 15 secondes et retrouve tes potes dans un serveur bien à vous.
            </p>
            <div className="relative mt-7 flex flex-col justify-center gap-3 sm:flex-row">
              <Link
                href={startHref}
                className="inline-flex items-center justify-center gap-2 rounded-2xl bg-ink px-6 py-3.5 font-bold text-white transition hover:bg-black"
              >
                {user ? "Ouvrir Poto" : "Créer mon compte gratuit"}
              </Link>
              <Link
                href={joinHref(DEMO_INVITE_CODE)}
                className="inline-flex items-center justify-center rounded-2xl border border-white/40 bg-white/10 px-6 py-3.5 font-semibold text-white backdrop-blur transition hover:bg-white/20"
              >
                Tester avec le code POTO
              </Link>
            </div>
          </div>
        </section>
      </main>

      <footer className="relative z-10 border-t border-white/10">
        <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-4 px-5 py-8 text-center sm:flex-row sm:px-8 sm:text-left">
          <div className="flex items-center gap-2.5">
            <span className="grid h-8 w-8 place-items-center rounded-xl bg-gradient-to-br from-brand to-pink text-sm">
              💬
            </span>
            <span className="font-black">Poto</span>
            <span className="text-xs text-muted">— la messagerie de tes potes</span>
          </div>
          <div className="flex items-center gap-5 text-xs font-medium text-muted">
            <Link href="/connexion" className="transition hover:text-white">
              Connexion
            </Link>
            <Link href="/inscription" className="transition hover:text-white">
              Inscription
            </Link>
            <span>Fait avec Next.js + PostgreSQL</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
