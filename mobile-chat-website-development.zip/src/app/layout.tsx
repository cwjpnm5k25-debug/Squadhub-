import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Poto — la messagerie de tes potes",
  description:
    "Crée ton compte, ouvre un serveur, partage le code à tes potes et discutez en direct. Gratuit, rapide, pensé mobile.",
  applicationName: "Poto",
  manifest: "/manifest.webmanifest",
  icons: {
    icon: [
      { url: "/icon.svg", type: "image/svg+xml" },
      { url: "/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/icon-512.png", sizes: "512x512" }],
  },
  appleWebApp: {
    capable: true,
    title: "Poto",
    statusBarStyle: "black-translucent",
  },
  openGraph: {
    title: "Poto — la messagerie de tes potes",
    description:
      "Des serveurs gratuits, des salons, des invitations par code. Ton groupe de potes en ligne en 30 secondes.",
    type: "website",
    locale: "fr_FR",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  themeColor: "#08080f",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fr">
      <body className="min-h-full bg-ink text-white antialiased selection:bg-brand/40">
        {children}
      </body>
    </html>
  );
}
