export type ApiUser = {
  id: number;
  username: string;
  displayName: string;
};

export type ChannelDTO = {
  id: number;
  name: string;
};

export type ServerSummaryDTO = {
  id: number;
  name: string;
  emoji: string;
  description: string | null;
  role: "owner" | "member";
  inviteCode: string;
  isPublic: boolean;
  memberCount: number;
  onlineCount: number;
  channels: ChannelDTO[];
};

export type HubDTO = {
  servers: ServerSummaryDTO[];
};

export type MemberDTO = {
  id: number;
  username: string;
  displayName: string;
  role: "owner" | "member";
  online: boolean;
  joinedAt: string;
};

export type MessageDTO = {
  id: number;
  content: string;
  createdAt: string;
  author: ApiUser;
};

export type ChannelViewDTO = {
  id: number;
  name: string;
  serverId: number;
  serverName: string;
  serverEmoji: string;
};

export type MessagesResponse = {
  channel: ChannelViewDTO;
  messages: MessageDTO[];
  onlineCount: number;
};

export type PublicServerDTO = {
  id: number;
  name: string;
  emoji: string;
  description: string | null;
  inviteCode: string;
  memberCount: number;
  onlineCount: number;
  joined: boolean;
};
