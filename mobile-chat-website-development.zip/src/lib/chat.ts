import { randomBytes } from "node:crypto";
import { and, asc, desc, eq, gt, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { channels, messages, serverMembers, servers, users } from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import type {
  ChannelViewDTO,
  HubDTO,
  MemberDTO,
  MessageDTO,
  MessagesResponse,
  PublicServerDTO,
  ServerSummaryDTO,
} from "@/lib/types";

const ONLINE_WINDOW_MS = 90 * 1000;
export const DEMO_INVITE_CODE = "POTO";

function isOnline(lastSeenAt: Date | null): boolean {
  if (!lastSeenAt) return false;
  return Date.now() - lastSeenAt.getTime() < ONLINE_WINDOW_MS;
}

const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export function generateInviteCode(length = 6): string {
  const bytes = randomBytes(length);
  let code = "";
  for (let i = 0; i < length; i += 1) {
    code += CODE_ALPHABET[bytes[i] % CODE_ALPHABET.length];
  }
  return code;
}

async function uniqueInviteCode(): Promise<string> {
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const code = generateInviteCode();
    const existing = await db
      .select({ id: servers.id })
      .from(servers)
      .where(eq(servers.inviteCode, code))
      .limit(1);
    if (existing.length === 0) return code;
  }
  return generateInviteCode(8);
}

export async function getHub(userId: number): Promise<HubDTO> {
  const memberships = await db
    .select({
      role: serverMembers.role,
      id: servers.id,
      name: servers.name,
      emoji: servers.emoji,
      description: servers.description,
      inviteCode: servers.inviteCode,
      isPublic: servers.isPublic,
    })
    .from(serverMembers)
    .innerJoin(servers, eq(servers.id, serverMembers.serverId))
    .where(eq(serverMembers.userId, userId))
    .orderBy(asc(servers.id));

  if (memberships.length === 0) {
    return { servers: [] };
  }

  const serverIds = memberships.map((row) => row.id);

  const [channelRows, memberRows] = await Promise.all([
    db
      .select({ id: channels.id, serverId: channels.serverId, name: channels.name })
      .from(channels)
      .where(inArray(channels.serverId, serverIds))
      .orderBy(asc(channels.id)),
    db
      .select({ serverId: serverMembers.serverId, lastSeenAt: users.lastSeenAt })
      .from(serverMembers)
      .innerJoin(users, eq(users.id, serverMembers.userId))
      .where(inArray(serverMembers.serverId, serverIds)),
  ]);

  const serverSummaries: ServerSummaryDTO[] = memberships.map((membership) => {
    const serverChannels = channelRows
      .filter((channel) => channel.serverId === membership.id)
      .map((channel) => ({ id: channel.id, name: channel.name }));
    const serverMembersList = memberRows.filter((member) => member.serverId === membership.id);

    return {
      id: membership.id,
      name: membership.name,
      emoji: membership.emoji,
      description: membership.description,
      role: membership.role === "owner" ? "owner" : "member",
      inviteCode: membership.inviteCode,
      isPublic: membership.isPublic,
      memberCount: serverMembersList.length,
      onlineCount: serverMembersList.filter((member) => isOnline(member.lastSeenAt)).length,
      channels: serverChannels,
    };
  });

  return { servers: serverSummaries };
}

export async function getServerMembers(userId: number, serverId: number): Promise<MemberDTO[] | null> {
  const membership = await db
    .select({ id: serverMembers.id })
    .from(serverMembers)
    .where(and(eq(serverMembers.serverId, serverId), eq(serverMembers.userId, userId)))
    .limit(1);

  if (membership.length === 0) return null;

  const rows = await db
    .select({
      id: users.id,
      username: users.username,
      displayName: users.displayName,
      lastSeenAt: users.lastSeenAt,
      role: serverMembers.role,
      joinedAt: serverMembers.joinedAt,
    })
    .from(serverMembers)
    .innerJoin(users, eq(users.id, serverMembers.userId))
    .where(eq(serverMembers.serverId, serverId))
    .orderBy(asc(serverMembers.joinedAt));

  return rows.map((row) => ({
    id: row.id,
    username: row.username,
    displayName: row.displayName,
    role: row.role === "owner" ? "owner" : "member",
    online: isOnline(row.lastSeenAt),
    joinedAt: row.joinedAt.toISOString(),
  }));
}

async function findAccessibleChannel(userId: number, channelId: number) {
  const rows = await db
    .select({
      id: channels.id,
      name: channels.name,
      serverId: servers.id,
      serverName: servers.name,
      serverEmoji: servers.emoji,
    })
    .from(channels)
    .innerJoin(servers, eq(servers.id, channels.serverId))
    .innerJoin(
      serverMembers,
      and(eq(serverMembers.serverId, servers.id), eq(serverMembers.userId, userId)),
    )
    .where(eq(channels.id, channelId))
    .limit(1);

  return rows[0] ?? null;
}

export async function getChannelMessages(
  userId: number,
  channelId: number,
  after?: number,
): Promise<MessagesResponse | null> {
  const channel = await findAccessibleChannel(userId, channelId);
  if (!channel) return null;

  const baseQuery = db
    .select({
      id: messages.id,
      content: messages.content,
      createdAt: messages.createdAt,
      authorId: users.id,
      username: users.username,
      displayName: users.displayName,
    })
    .from(messages)
    .innerJoin(users, eq(users.id, messages.authorId));

  const rows =
    typeof after === "number" && after > 0
      ? await baseQuery
          .where(and(eq(messages.channelId, channelId), gt(messages.id, after)))
          .orderBy(asc(messages.id))
          .limit(100)
      : (
          await baseQuery
            .where(eq(messages.channelId, channelId))
            .orderBy(desc(messages.id))
            .limit(80)
        ).reverse();

  const messageList: MessageDTO[] = rows.map((row) => ({
    id: row.id,
    content: row.content,
    createdAt: row.createdAt.toISOString(),
    author: { id: row.authorId, username: row.username, displayName: row.displayName },
  }));

  const memberRows = await db
    .select({ lastSeenAt: users.lastSeenAt })
    .from(serverMembers)
    .innerJoin(users, eq(users.id, serverMembers.userId))
    .where(eq(serverMembers.serverId, channel.serverId));

  const channelView: ChannelViewDTO = {
    id: channel.id,
    name: channel.name,
    serverId: channel.serverId,
    serverName: channel.serverName,
    serverEmoji: channel.serverEmoji,
  };

  return {
    channel: channelView,
    messages: messageList,
    onlineCount: memberRows.filter((row) => isOnline(row.lastSeenAt)).length,
  };
}

export async function postMessage(
  userId: number,
  channelId: number,
  content: string,
): Promise<MessageDTO | null> {
  const channel = await findAccessibleChannel(userId, channelId);
  if (!channel) return null;

  const [inserted] = await db
    .insert(messages)
    .values({ channelId, authorId: userId, content })
    .returning({ id: messages.id, content: messages.content, createdAt: messages.createdAt });

  const [author] = await db
    .select({ id: users.id, username: users.username, displayName: users.displayName })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);

  return {
    id: inserted.id,
    content: inserted.content,
    createdAt: inserted.createdAt.toISOString(),
    author,
  };
}

export async function createServerForUser(options: {
  userId: number;
  name: string;
  emoji: string;
  description?: string;
  isPublic?: boolean;
}): Promise<{ serverId: number; inviteCode: string; channelId: number }> {
  const inviteCode = await uniqueInviteCode();

  return db.transaction(async (tx) => {
    const [server] = await tx
      .insert(servers)
      .values({
        name: options.name,
        emoji: options.emoji,
        description: options.description ?? null,
        isPublic: options.isPublic ?? false,
        ownerId: options.userId,
        inviteCode,
      })
      .returning({ id: servers.id });

    await tx.insert(serverMembers).values({
      serverId: server.id,
      userId: options.userId,
      role: "owner",
    });

    const [firstChannel] = await tx
      .insert(channels)
      .values([
        { serverId: server.id, name: "général" },
        { serverId: server.id, name: "blabla" },
      ])
      .returning({ id: channels.id });

    return { serverId: server.id, inviteCode, channelId: firstChannel.id };
  });
}

export async function joinServerByCode(
  userId: number,
  rawCode: string,
): Promise<{ serverId: number; alreadyMember: boolean } | null> {
  const code = rawCode.trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
  if (code.length < 4) return null;

  const [server] = await db
    .select({ id: servers.id })
    .from(servers)
    .where(eq(servers.inviteCode, code))
    .limit(1);

  if (!server) return null;

  const existing = await db
    .select({ id: serverMembers.id })
    .from(serverMembers)
    .where(and(eq(serverMembers.serverId, server.id), eq(serverMembers.userId, userId)))
    .limit(1);

  if (existing.length > 0) {
    return { serverId: server.id, alreadyMember: true };
  }

  await db.insert(serverMembers).values({ serverId: server.id, userId, role: "member" });
  return { serverId: server.id, alreadyMember: false };
}

export async function regenerateInviteCode(
  userId: number,
  serverId: number,
): Promise<string | null> {
  const [owned] = await db
    .select({ id: servers.id })
    .from(servers)
    .where(and(eq(servers.id, serverId), eq(servers.ownerId, userId)))
    .limit(1);

  if (!owned) return null;

  const code = await uniqueInviteCode();
  await db.update(servers).set({ inviteCode: code }).where(eq(servers.id, serverId));
  return code;
}

export async function createChannel(
  userId: number,
  serverId: number,
  name: string,
): Promise<number | null> {
  const [membership] = await db
    .select({ id: serverMembers.id })
    .from(serverMembers)
    .where(and(eq(serverMembers.serverId, serverId), eq(serverMembers.userId, userId)))
    .limit(1);

  if (!membership) return null;

  const clean = name
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9-]/g, "")
    .slice(0, 24);

  if (!clean) return null;

  const [channel] = await db
    .insert(channels)
    .values({ serverId, name: clean })
    .returning({ id: channels.id });

  return channel.id;
}

export async function leaveServer(userId: number, serverId: number): Promise<boolean> {
  const [membership] = await db
    .select({ id: serverMembers.id, role: serverMembers.role })
    .from(serverMembers)
    .where(and(eq(serverMembers.serverId, serverId), eq(serverMembers.userId, userId)))
    .limit(1);

  if (!membership || membership.role === "owner") return false;

  await db.delete(serverMembers).where(eq(serverMembers.id, membership.id));
  return true;
}

export async function getPublicServers(userId: number | null): Promise<PublicServerDTO[]> {
  const rows = await db
    .select({
      id: servers.id,
      name: servers.name,
      emoji: servers.emoji,
      description: servers.description,
      inviteCode: servers.inviteCode,
    })
    .from(servers)
    .where(eq(servers.isPublic, true))
    .orderBy(asc(servers.id))
    .limit(24);

  if (rows.length === 0) return [];

  const ids = rows.map((row) => row.id);
  const memberRows = await db
    .select({ serverId: serverMembers.serverId, userId: serverMembers.userId, lastSeenAt: users.lastSeenAt })
    .from(serverMembers)
    .innerJoin(users, eq(users.id, serverMembers.userId))
    .where(inArray(serverMembers.serverId, ids));

  return rows.map((row) => {
    const members = memberRows.filter((member) => member.serverId === row.id);
    return {
      id: row.id,
      name: row.name,
      emoji: row.emoji,
      description: row.description,
      inviteCode: row.inviteCode,
      memberCount: members.length,
      onlineCount: members.filter((member) => isOnline(member.lastSeenAt)).length,
      joined: userId !== null && members.some((member) => member.userId === userId),
    };
  });
}

/**
 * Crée (une seule fois) le serveur public de démonstration accessible avec le code POTO.
 * Le faire à la demande évite d'avoir besoin d'un script de seed au déploiement.
 */
export async function ensureDemoServer(): Promise<void> {
  const existing = await db
    .select({ id: servers.id })
    .from(servers)
    .where(eq(servers.inviteCode, DEMO_INVITE_CODE))
    .limit(1);

  if (existing.length > 0) {
    // Le bot de démo reste "en ligne" pour que le serveur public soit vivant.
    await db
      .execute(
        sql`update users set last_seen_at = now() where username = 'potobot' and last_seen_at < now() - interval '60 seconds'`,
      )
      .catch(() => undefined);
    return;
  }

  try {
    const passwordHash = await hashPassword(randomBytes(18).toString("hex"));

    const [bot] = await db
      .insert(users)
      .values({ username: "potobot", displayName: "PotoBot", passwordHash })
      .onConflictDoNothing({ target: users.username })
      .returning({ id: users.id });

    const botId =
      bot?.id ??
      (
        await db
          .select({ id: users.id })
          .from(users)
          .where(eq(users.username, "potobot"))
          .limit(1)
      )[0]?.id;

    if (!botId) return;

    const [server] = await db
      .insert(servers)
      .values({
        name: "Le QG des potes",
        emoji: "🔥",
        description: "Le serveur public de Poto : présente-toi et trouve des potes pour discuter.",
        isPublic: true,
        ownerId: botId,
        inviteCode: DEMO_INVITE_CODE,
      })
      .onConflictDoNothing({ target: servers.inviteCode })
      .returning({ id: servers.id });

    if (!server) return;

    await db
      .insert(serverMembers)
      .values({ serverId: server.id, userId: botId, role: "owner" })
      .onConflictDoNothing();

    const created = await db
      .insert(channels)
      .values([
        { serverId: server.id, name: "général" },
        { serverId: server.id, name: "présentations" },
        { serverId: server.id, name: "memes" },
        { serverId: server.id, name: "musique" },
      ])
      .returning({ id: channels.id, name: channels.name });

    const general = created.find((channel) => channel.name === "général") ?? created[0];
    const presentations = created.find((channel) => channel.name === "présentations");

    if (general) {
      await db.insert(messages).values([
        {
          channelId: general.id,
          authorId: botId,
          content:
            "Bienvenue sur Poto 🔥 Ici c'est le serveur public : crée ton salon, invite tes potes, et discute en direct.",
        },
        {
          channelId: general.id,
          authorId: botId,
          content:
            "Astuce : pour avoir vos propres salons privés, clique sur le + en haut à gauche, puis partage le code d'invitation à tes potes.",
        },
        {
          channelId: general.id,
          authorId: botId,
          content: "Nouveau ici ? Passe dans #présentations, ça fait toujours plaisir 👋",
        },
      ]);
    }

    if (presentations) {
      await db.insert(messages).values({
        channelId: presentations.id,
        authorId: botId,
        content: "Présente-toi en 3 lignes : ton prénom, ce que tu aimes, et ton emoji du moment 😄",
      });
    }
  } catch {
    // En cas de course entre deux requêtes, le serveur de démo existe déjà : on ignore.
  }
}

export async function countServers(): Promise<number> {
  const [row] = await db.select({ count: sql<number>`count(*)::int` }).from(servers);
  return row?.count ?? 0;
}

export async function getPlatformStats(): Promise<{
  servers: number;
  users: number;
  messages: number;
}> {
  const [serverRow, userRow, messageRow] = await Promise.all([
    db.select({ count: sql<number>`count(*)::int` }).from(servers),
    db.select({ count: sql<number>`count(*)::int` }).from(users),
    db.select({ count: sql<number>`count(*)::int` }).from(messages),
  ]);

  return {
    servers: serverRow[0]?.count ?? 0,
    users: userRow[0]?.count ?? 0,
    messages: messageRow[0]?.count ?? 0,
  };
}
