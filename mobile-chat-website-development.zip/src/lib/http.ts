import type { SessionUser } from "@/lib/auth";
import { getCurrentUser } from "@/lib/auth";

export function jsonError(message: string, status = 400) {
  return Response.json({ error: message }, { status });
}

export async function readJson(request: Request): Promise<Record<string, unknown>> {
  try {
    const data = await request.json();
    if (!data || typeof data !== "object" || Array.isArray(data)) return {};
    return data as Record<string, unknown>;
  } catch {
    return {};
  }
}

export function stringField(body: Record<string, unknown>, key: string, maxLength = 400): string {
  const value = body[key];
  if (typeof value !== "string") return "";
  return value.trim().slice(0, maxLength);
}

export async function requireUser(): Promise<
  { user: SessionUser; response?: never } | { user?: never; response: Response }
> {
  const user = await getCurrentUser();
  if (!user) {
    return { response: jsonError("Tu dois être connecté pour faire ça.", 401) };
  }
  return { user };
}

export function parseId(raw: string): number | null {
  const id = Number(raw);
  if (!Number.isInteger(id) || id <= 0) return null;
  return id;
}

export function publicUser(user: SessionUser) {
  return { id: user.id, username: user.username, displayName: user.displayName };
}
