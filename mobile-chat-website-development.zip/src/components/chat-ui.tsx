"use client";

import { useEffect, type ReactNode } from "react";
import { avatarGradient, initials } from "@/lib/ui";

export const inputClass =
  "w-full rounded-xl border border-line bg-panel-2 px-3.5 py-3 text-[15px] text-white outline-none transition placeholder:text-muted/60 focus:border-brand focus:ring-2 focus:ring-brand/25";

export const primaryButton =
  "inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-brand to-pink px-4 py-3 text-sm font-bold text-white shadow-lg shadow-brand/20 transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-50";

export const ghostButton =
  "inline-flex items-center justify-center gap-2 rounded-xl border border-white/12 bg-white/5 px-4 py-3 text-sm font-semibold text-white/90 transition hover:bg-white/10 disabled:opacity-50";

export function Avatar({
  name,
  seed,
  size = "md",
  online,
}: {
  name: string;
  seed?: string | number;
  size?: "xs" | "sm" | "md" | "lg";
  online?: boolean;
}) {
  const dimensions = {
    xs: "h-7 w-7 text-[10px]",
    sm: "h-8 w-8 text-[11px]",
    md: "h-10 w-10 text-xs",
    lg: "h-16 w-16 text-lg",
  }[size];

  return (
    <span className="relative inline-flex shrink-0">
      <span
        className={`grid place-items-center rounded-full bg-gradient-to-br ${avatarGradient(
          seed ?? name,
        )} ${dimensions} font-black text-white`}
      >
        {initials(name)}
      </span>
      {online !== undefined ? (
        <span
          className={`absolute -right-0.5 -bottom-0.5 h-2.5 w-2.5 rounded-full border-2 border-panel ${
            online ? "bg-mint" : "bg-zinc-600"
          }`}
        />
      ) : null}
    </span>
  );
}

export function Sheet({
  open,
  onClose,
  title,
  subtitle,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      <button
        aria-label="Fermer"
        onClick={onClose}
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
      />
      <div className="animate-pop relative z-10 max-h-[92dvh] w-full overflow-y-auto rounded-t-3xl border border-white/10 bg-panel p-5 shadow-2xl sm:max-w-lg sm:rounded-3xl sm:p-6">
        <div className="mb-4 flex items-start justify-between gap-4">
          <div>
            <h2 className="text-lg font-black tracking-tight">{title}</h2>
            {subtitle ? <p className="mt-1 text-xs text-muted">{subtitle}</p> : null}
          </div>
          <button
            onClick={onClose}
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-white/5 text-muted transition hover:bg-white/10 hover:text-white"
            aria-label="Fermer"
          >
            ✕
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function CopyField({
  value,
  onCopy,
  label,
}: {
  value: string;
  onCopy: () => void;
  label?: string;
}) {
  return (
    <button
      onClick={onCopy}
      className="group flex w-full items-center gap-3 rounded-2xl border border-white/10 bg-ink/70 px-4 py-3 text-left transition hover:border-brand/40"
    >
      <div className="min-w-0 flex-1">
        {label ? (
          <p className="text-[10px] font-bold tracking-widest text-muted uppercase">{label}</p>
        ) : null}
        <p className="truncate font-mono text-sm text-white/90">{value}</p>
      </div>
      <span className="shrink-0 rounded-lg bg-white/5 px-2.5 py-1.5 text-[11px] font-semibold text-brand-soft transition group-hover:bg-brand/20">
        Copier
      </span>
    </button>
  );
}

export function EmptyState({
  emoji,
  title,
  text,
  children,
}: {
  emoji: string;
  title: string;
  text: string;
  children?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center px-6 py-10 text-center">
      <div className="grid h-16 w-16 place-items-center rounded-3xl bg-gradient-to-br from-brand/25 to-pink/20 text-3xl">
        {emoji}
      </div>
      <h3 className="mt-4 text-base font-bold">{title}</h3>
      <p className="mt-1.5 max-w-xs text-sm leading-relaxed text-muted">{text}</p>
      {children ? <div className="mt-5 flex w-full max-w-xs flex-col gap-2">{children}</div> : null}
    </div>
  );
}
