"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Avatar,
  CopyField,
  EmptyState,
  Sheet,
  ghostButton,
  inputClass,
  primaryButton,
} from "@/components/chat-ui";
import type {
  ApiUser,
  ChannelViewDTO,
  HubDTO,
  MemberDTO,
  MessageDTO,
  MessagesResponse,
  PublicServerDTO,
  ServerSummaryDTO,
} from "@/lib/types";
import { dayLabel, formatTime, inviteLink, sameDay } from "@/lib/ui";

type LocalMessage = MessageDTO & { pending?: boolean; failed?: boolean };
type Dialog =
  | "nav"
  | "server"
  | "join"
  | "discover"
  | "invite"
  | "members"
  | "channel"
  | "account"
  | null;
type Toast = { type: "success" | "error"; text: string } | null;

const SERVER_EMOJIS = ["🔥", "🎮", "🎵", "⚽", "🍕", "💜", "🚀", "🐶", "🎬", "🌈", "📚", "🎨"];
const POLL_MESSAGES_MS = 2500;
const POLL_HUB_MS = 20000;

export function ChatApp({
  initialUser,
  initialInvite,
}: {
  initialUser: ApiUser;
  initialInvite?: string;
}) {
  const router = useRouter();
  const user = initialUser;

  const [servers, setServers] = useState<ServerSummaryDTO[]>([]);
  const [activeServerId, setActiveServerId] = useState<number | null>(null);
  const [activeChannelId, setActiveChannelId] = useState<number | null>(null);
  const [channelView, setChannelView] = useState<ChannelViewDTO | null>(null);
  const [messages, setMessages] = useState<LocalMessage[]>([]);
  const [members, setMembers] = useState<MemberDTO[]>([]);
  const [onlineCount, setOnlineCount] = useState(0);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [ready, setReady] = useState(false);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [busy, setBusy] = useState(false);
  const [dialog, setDialog] = useState<Dialog>(null);
  const [toast, setToast] = useState<Toast>(null);

  const [joinCode, setJoinCode] = useState("");
  const [serverName, setServerName] = useState("");
  const [serverEmoji, setServerEmoji] = useState("🔥");
  const [serverDesc, setServerDesc] = useState("");
  const [serverPublic, setServerPublic] = useState(false);
  const [channelName, setChannelName] = useState("");
  const [discoverList, setDiscoverList] = useState<PublicServerDTO[]>([]);
  const [discoverLoading, setDiscoverLoading] = useState(false);

  const activeServer = useMemo(
    () => servers.find((server) => server.id === activeServerId) ?? null,
    [servers, activeServerId],
  );
  const activeChannel = useMemo(
    () => activeServer?.channels.find((channel) => channel.id === activeChannelId) ?? null,
    [activeServer, activeChannelId],
  );

  const scrollRef = useRef<HTMLDivElement>(null);
  const nearBottomRef = useRef(true);

  const showToast = useCallback((type: "success" | "error", text: string) => {
    setToast({ type, text });
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timeout = setTimeout(() => setToast(null), 4200);
    return () => clearTimeout(timeout);
  }, [toast]);

  const loadHub = useCallback(async (): Promise<HubDTO | null> => {
    try {
      const response = await fetch("/api/hub", { cache: "no-store" });
      if (response.status === 401) {
        router.replace("/connexion");
        return null;
      }
      if (!response.ok) return null;
      const data = (await response.json()) as HubDTO & { demoCode: string };
      setServers(data.servers);
      setActiveServerId((current) =>
        current && data.servers.some((server) => server.id === current)
          ? current
          : (data.servers[0]?.id ?? null),
      );
      return data;
    } catch {
      return null;
    }
  }, [router]);

  const joinByCode = useCallback(
    async (rawCode: string) => {
      const code = rawCode.trim().toUpperCase();
      if (!code) {
        showToast("error", "Entre un code d'invitation.");
        return false;
      }
      setBusy(true);
      try {
        const response = await fetch("/api/servers/join", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ code }),
        });
        const data = (await response.json().catch(() => ({}))) as {
          serverId?: number;
          alreadyMember?: boolean;
          error?: string;
        };
        if (!response.ok || !data.serverId) {
          showToast("error", data.error ?? "Impossible de rejoindre ce serveur.");
          return false;
        }
        await loadHub();
        setActiveServerId(data.serverId);
        setDialog(null);
        setJoinCode("");
        showToast(
          "success",
          data.alreadyMember ? "Tu es déjà dans ce serveur 👍" : "Bienvenue dans le serveur ! 🎉",
        );
        return true;
      } catch {
        showToast("error", "Connexion impossible. Réessaie.");
        return false;
      } finally {
        setBusy(false);
      }
    },
    [loadHub, showToast],
  );

  // Chargement initial + traitement d'un éventuel lien d'invitation.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const data = await loadHub();
      if (cancelled) return;
      setReady(true);
      if (initialInvite) {
        await joinByCode(initialInvite);
        if (typeof window !== "undefined") {
          window.history.replaceState(null, "", "/app");
        }
      } else if (data && data.servers.length === 0) {
        setDialog("join");
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Rafraîchissement régulier des compteurs / nouveaux salons.
  useEffect(() => {
    const interval = setInterval(() => {
      void loadHub();
    }, POLL_HUB_MS);
    return () => clearInterval(interval);
  }, [loadHub]);

  // Sélection du bon salon quand le serveur change.
  useEffect(() => {
    if (!activeServer) {
      setActiveChannelId(null);
      return;
    }
    if (activeServer.channels.some((channel) => channel.id === activeChannelId)) return;

    let saved: number | null = null;
    try {
      saved = Number(window.localStorage.getItem(`poto:channel:${activeServer.id}`));
    } catch {
      saved = null;
    }
    const next =
      activeServer.channels.find((channel) => channel.id === saved) ?? activeServer.channels[0];
    setActiveChannelId(next ? next.id : null);
  }, [activeServer, activeChannelId]);

  useEffect(() => {
    if (!activeServerId || !activeChannelId) return;
    try {
      window.localStorage.setItem(`poto:channel:${activeServerId}`, String(activeChannelId));
    } catch {
      // stockage local indisponible : pas grave
    }
  }, [activeServerId, activeChannelId]);

  // Messages du salon actif + polling temps réel.
  useEffect(() => {
    if (!activeChannelId) {
      setMessages([]);
      setChannelView(null);
      return;
    }

    let cancelled = false;
    let lastId = 0;
    setMessages([]);
    setLoadingMessages(true);

    const load = async (initial: boolean) => {
      try {
        const url = `/api/channels/${activeChannelId}/messages${initial ? "" : `?after=${lastId}`}`;
        const response = await fetch(url, { cache: "no-store" });
        if (response.status === 401) {
          router.replace("/connexion");
          return;
        }
        if (!response.ok) return;
        const data = (await response.json()) as MessagesResponse;
        if (cancelled) return;

        setChannelView(data.channel);
        setOnlineCount(data.onlineCount);
        if (data.messages.length > 0) {
          lastId = Math.max(lastId, ...data.messages.map((message) => message.id));
        }

        setMessages((previous) => {
          const keptOptimistic = previous.filter((message) => message.id < 0);
          if (initial) return [...data.messages, ...keptOptimistic];
          const map = new Map<number, LocalMessage>();
          previous.forEach((message) => {
            if (message.id > 0) map.set(message.id, message);
          });
          data.messages.forEach((message) => map.set(message.id, message));
          return [...map.values(), ...keptOptimistic].sort(
            (a, b) =>
              new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime() || a.id - b.id,
          );
        });
      } catch {
        // on retentera au prochain tick
      } finally {
        if (!cancelled && initial) setLoadingMessages(false);
      }
    };

    void load(true);
    const interval = setInterval(() => void load(false), POLL_MESSAGES_MS);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [activeChannelId, router]);

  // Membres du serveur actif.
  useEffect(() => {
    if (!activeServerId) {
      setMembers([]);
      return;
    }
    let cancelled = false;
    const load = async () => {
      try {
        const response = await fetch(`/api/servers/${activeServerId}/members`, {
          cache: "no-store",
        });
        if (!response.ok) return;
        const data = (await response.json()) as { members: MemberDTO[] };
        if (cancelled) return;
        setMembers(data.members);
        setOnlineCount(data.members.filter((member) => member.online).length);
      } catch {
        // silencieux
      }
    };
    void load();
    const interval = setInterval(() => void load(), 15000);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [activeServerId]);

  // Decouverte des serveurs publics à l'ouverture du tiroir.
  useEffect(() => {
    if (dialog !== "discover") return;
    let cancelled = false;
    setDiscoverLoading(true);
    (async () => {
      try {
        const response = await fetch("/api/discover", { cache: "no-store" });
        const data = (await response.json()) as { servers?: PublicServerDTO[] };
        if (!cancelled) setDiscoverList(data.servers ?? []);
      } catch {
        if (!cancelled) setDiscoverList([]);
      } finally {
        if (!cancelled) setDiscoverLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [dialog]);

  // Scroll intelligent.
  useEffect(() => {
    const element = scrollRef.current;
    if (!element) return;
    if (nearBottomRef.current) {
      element.scrollTop = element.scrollHeight;
    }
  }, [messages]);

  useEffect(() => {
    nearBottomRef.current = true;
    const element = scrollRef.current;
    if (element) {
      requestAnimationFrame(() => {
        element.scrollTop = element.scrollHeight;
      });
    }
  }, [activeChannelId]);

  const handleScroll = () => {
    const element = scrollRef.current;
    if (!element) return;
    nearBottomRef.current = element.scrollHeight - element.scrollTop - element.clientHeight < 150;
  };

  async function sendMessage(event?: React.FormEvent) {
    event?.preventDefault();
    const content = draft.trim();
    if (!content || !activeChannelId || sending) return;

    const channelId = activeChannelId;
    const tempId = -Date.now();
    const optimistic: LocalMessage = {
      id: tempId,
      content,
      createdAt: new Date().toISOString(),
      author: user,
      pending: true,
    };

    setDraft("");
    setSending(true);
    nearBottomRef.current = true;
    setMessages((previous) => [...previous, optimistic]);

    try {
      const response = await fetch(`/api/channels/${channelId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
      });
      const data = (await response.json().catch(() => ({}))) as {
        message?: MessageDTO;
        error?: string;
      };
      const savedMessage = data.message;

      if (!response.ok || !savedMessage) {
        setMessages((previous) =>
          previous.map((message) =>
            message.id === tempId ? { ...message, pending: false, failed: true } : message,
          ),
        );
        showToast("error", data.error ?? "Message non envoyé. Réessaie.");
        return;
      }

      setMessages((previous) => {
        const withoutTemp = previous.filter((message) => message.id !== tempId);
        if (withoutTemp.some((message) => message.id === savedMessage.id)) return withoutTemp;
        return [...withoutTemp, savedMessage];
      });
    } catch {
      setMessages((previous) =>
        previous.map((message) =>
          message.id === tempId ? { ...message, pending: false, failed: true } : message,
        ),
      );
      showToast("error", "Message non envoyé. Vérifie ta connexion.");
    } finally {
      setSending(false);
    }
  }

  async function createServer(event: React.FormEvent) {
    event.preventDefault();
    if (serverName.trim().length < 2) {
      showToast("error", "Donne un nom d'au moins 2 caractères.");
      return;
    }
    setBusy(true);
    try {
      const response = await fetch("/api/servers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: serverName.trim(),
          emoji: serverEmoji,
          description: serverDesc.trim(),
          isPublic: serverPublic,
        }),
      });
      const data = (await response.json().catch(() => ({}))) as {
        serverId?: number;
        channelId?: number;
        inviteCode?: string;
        error?: string;
      };
      if (!response.ok || !data.serverId) {
        showToast("error", data.error ?? "Création impossible.");
        return;
      }
      await loadHub();
      setActiveServerId(data.serverId);
      if (data.channelId) setActiveChannelId(data.channelId);
      setDialog("invite");
      showToast("success", "Serveur créé ! Partage le code à tes potes 🎟️");
      setServerName("");
      setServerDesc("");
      setServerPublic(false);
    } catch {
      showToast("error", "Création impossible. Réessaie.");
    } finally {
      setBusy(false);
    }
  }

  async function createChannel(event: React.FormEvent) {
    event.preventDefault();
    if (!activeServerId || channelName.trim().length < 2) {
      showToast("error", "Donne un nom d'au moins 2 caractères.");
      return;
    }
    setBusy(true);
    try {
      const response = await fetch(`/api/servers/${activeServerId}/channels`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: channelName }),
      });
      const data = (await response.json().catch(() => ({}))) as {
        channelId?: number;
        error?: string;
      };
      if (!response.ok || !data.channelId) {
        showToast("error", data.error ?? "Création impossible.");
        return;
      }
      await loadHub();
      setActiveChannelId(data.channelId);
      setChannelName("");
      setDialog(null);
      showToast("success", "Salon créé !");
    } catch {
      showToast("error", "Création impossible. Réessaie.");
    } finally {
      setBusy(false);
    }
  }

  async function copyText(text: string, label = "Copié !") {
    try {
      await navigator.clipboard.writeText(text);
      showToast("success", label);
    } catch {
      showToast("error", "Copie impossible sur ce navigateur.");
    }
  }

  async function regenerateCode() {
    if (!activeServerId) return;
    setBusy(true);
    try {
      const response = await fetch(`/api/servers/${activeServerId}/invite`, { method: "POST" });
      const data = (await response.json().catch(() => ({}))) as {
        inviteCode?: string;
        error?: string;
      };
      if (!response.ok || !data.inviteCode) {
        showToast("error", data.error ?? "Impossible de changer le code.");
        return;
      }
      const nextCode = data.inviteCode;
      setServers((previous) =>
        previous.map((server) =>
          server.id === activeServerId ? { ...server, inviteCode: nextCode } : server,
        ),
      );
      showToast("success", "Nouveau code généré ! L'ancien ne marche plus.");
    } catch {
      showToast("error", "Impossible de changer le code.");
    } finally {
      setBusy(false);
    }
  }

  async function shareInvite() {
    if (!activeServer) return;
    const url = inviteLink(activeServer.inviteCode);
    const text = `Rejoins-moi sur Poto dans le serveur ${activeServer.name} ! Code : ${activeServer.inviteCode} → ${url}`;
    if (typeof navigator !== "undefined" && navigator.share) {
      try {
        await navigator.share({ title: "Poto", text, url });
        return;
      } catch {
        // partage annulé : on copie à la place
      }
    }
    await copyText(text, "Lien d'invitation copié !");
  }

  async function leaveServer() {
    if (!activeServer) return;
    if (!window.confirm(`Quitter le serveur « ${activeServer.name} » ?`)) return;
    setBusy(true);
    try {
      const response = await fetch(`/api/servers/${activeServer.id}/leave`, { method: "POST" });
      if (!response.ok) {
        const data = (await response.json().catch(() => ({}))) as { error?: string };
        showToast("error", data.error ?? "Impossible de quitter ce serveur.");
        return;
      }
      setDialog(null);
      await loadHub();
      showToast("success", "Tu as quitté le serveur.");
    } catch {
      showToast("error", "Impossible de quitter ce serveur.");
    } finally {
      setBusy(false);
    }
  }

  async function logout() {
    setBusy(true);
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      router.replace("/");
      router.refresh();
    } catch {
      showToast("error", "Déconnexion impossible.");
      setBusy(false);
    }
  }

  const membersOnline = members.filter((member) => member.online);
  const membersOffline = members.filter((member) => !member.online);
  const serversWithoutActive = servers.length === 0;
  const headerName = channelView?.serverName ?? activeServer?.name ?? "Poto";
  const headerEmoji = channelView?.serverEmoji ?? activeServer?.emoji ?? "💬";

  function renderMessages() {
    if (!activeChannelId) {
      return (
        <EmptyState
          emoji="🗂️"
          title="Choisis un salon"
          text="Sélectionne un salon à gauche, ou crée-en un nouveau pour lancer la discussion."
        >
          <button className={primaryButton} onClick={() => setDialog("channel")} disabled={!activeServer}>
            + Nouveau salon
          </button>
        </EmptyState>
      );
    }

    if (loadingMessages && messages.length === 0) {
      return (
        <div className="space-y-4 p-5">
          {[0, 1, 2, 3].map((row) => (
            <div key={row} className="flex animate-pulse gap-3">
              <div className="h-8 w-8 rounded-full bg-white/5" />
              <div className="flex-1 space-y-2">
                <div className="h-2.5 w-24 rounded bg-white/5" />
                <div className="h-3 w-2/3 rounded bg-white/5" />
              </div>
            </div>
          ))}
        </div>
      );
    }

    if (messages.length === 0) {
      return (
        <EmptyState
          emoji="👋"
          title={`#${activeChannel?.name ?? "salon"} est tout neuf`}
          text="Personne n'a encore parlé ici. Lance la conversation, tes potes vont suivre."
        />
      );
    }

    return (
      <div className="px-3 pt-3 pb-2 sm:px-5">
        {messages.map((message, index) => {
          const previous = messages[index - 1];
          const newDay = !previous || !sameDay(previous.createdAt, message.createdAt);
          const grouped =
            !newDay &&
            previous !== undefined &&
            previous.author.id === message.author.id &&
            new Date(message.createdAt).getTime() - new Date(previous.createdAt).getTime() <
              5 * 60 * 1000;
          const mine = message.author.id === user.id;

          return (
            <div key={message.id}>
              {newDay ? (
                <div className="my-4 flex items-center gap-3">
                  <div className="h-px flex-1 bg-line/70" />
                  <span className="text-[10px] font-bold tracking-widest text-muted uppercase">
                    {dayLabel(message.createdAt)}
                  </span>
                  <div className="h-px flex-1 bg-line/70" />
                </div>
              ) : null}
              <div
                className={`flex gap-2.5 rounded-2xl px-1 py-0.5 ${
                  grouped ? "mt-0.5" : "mt-3"
                } ${message.failed ? "opacity-70" : ""}`}
              >
                {grouped ? (
                  <span className="w-8 shrink-0" />
                ) : (
                  <Avatar name={message.author.displayName} seed={message.author.id} size="sm" />
                )}
                <div className="min-w-0 flex-1">
                  {grouped ? null : (
                    <div className="mb-0.5 flex items-center gap-2">
                      <span className="text-[12.5px] font-bold">{message.author.displayName}</span>
                      {mine ? (
                        <span className="rounded bg-brand/25 px-1.5 py-px text-[9px] font-bold text-brand-soft uppercase">
                          toi
                        </span>
                      ) : null}
                      <span className="text-[10px] text-muted">{formatTime(message.createdAt)}</span>
                    </div>
                  )}
                  <p
                    className={`text-[14px] leading-relaxed break-words whitespace-pre-wrap ${
                      message.failed ? "text-pink/80" : "text-white/90"
                    }`}
                  >
                    {message.content}
                  </p>
                  {message.pending ? (
                    <span className="text-[10px] text-muted">envoi…</span>
                  ) : null}
                  {message.failed ? (
                    <span className="text-[10px] text-pink">non envoyé — réessaie</span>
                  ) : null}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    );
  }

  return (
    <div className="flex h-[100dvh] w-full overflow-hidden bg-ink text-white">
      {/* Rail serveurs (desktop) */}
      <nav className="hidden w-[76px] shrink-0 flex-col items-center gap-2 border-r border-line/60 bg-panel/80 px-2 py-3 md:flex">
        <Link
          href="/"
          title="Accueil Poto"
          className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-brand via-purple-500 to-pink text-lg shadow-lg shadow-brand/30"
        >
          💬
        </Link>
        <div className="my-1 h-px w-8 bg-line/80" />
        <div className="no-scrollbar flex w-full flex-1 flex-col items-center gap-2 overflow-y-auto">
          {servers.map((server) => (
            <button
              key={server.id}
              onClick={() => setActiveServerId(server.id)}
              title={server.name}
              className={`relative grid h-12 w-12 place-items-center rounded-2xl text-xl transition ${
                activeServerId === server.id
                  ? "bg-gradient-to-br from-brand/40 to-pink/30 ring-2 ring-brand"
                  : "bg-white/5 hover:bg-white/10"
              }`}
            >
              {server.emoji}
              {server.onlineCount > 0 ? (
                <span className="absolute right-0.5 bottom-0.5 h-2 w-2 rounded-full border border-panel bg-mint" />
              ) : null}
            </button>
          ))}
          <button
            onClick={() => setDialog("server")}
            title="Créer un serveur"
            className="grid h-12 w-12 place-items-center rounded-2xl border border-dashed border-white/20 text-lg text-muted transition hover:border-brand/60 hover:text-white"
          >
            +
          </button>
          <button
            onClick={() => setDialog("discover")}
            title="Découvrir des serveurs"
            className="grid h-11 w-11 place-items-center rounded-2xl bg-white/5 text-base text-muted transition hover:bg-white/10 hover:text-white"
          >
            🧭
          </button>
        </div>
        <button onClick={() => setDialog("account")} title="Mon compte">
          <Avatar name={user.displayName} seed={user.id} size="sm" online />
        </button>
      </nav>

      {/* Colonne salons (desktop) */}
      <aside className="hidden w-[252px] shrink-0 flex-col border-r border-line/60 bg-panel/40 md:flex">
        <div className="border-b border-line/60 px-4 py-4">
          <div className="flex items-center gap-2.5">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-white/5 text-lg">
              {activeServer?.emoji ?? "💬"}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-black">{activeServer?.name ?? "Poto"}</p>
              <p className="truncate text-[11px] text-muted">
                {activeServer?.memberCount ?? 0} membres · {onlineCount} en ligne
              </p>
            </div>
          </div>
          <div className="mt-3 flex gap-1.5">
            <button
              onClick={() => setDialog("invite")}
              className="flex-1 rounded-lg border border-white/10 bg-white/5 px-2 py-2 text-[11px] font-bold transition hover:bg-white/10"
            >
              🎟️ Inviter
            </button>
            <button
              onClick={() => setDialog("join")}
              className="flex-1 rounded-lg border border-white/10 bg-white/5 px-2 py-2 text-[11px] font-bold transition hover:bg-white/10"
            >
              ➕ Rejoindre
            </button>
          </div>
        </div>

        <div className="no-scrollbar flex-1 overflow-y-auto px-2 py-3">
          <div className="flex items-center justify-between px-2 pb-1.5">
            <p className="text-[10px] font-bold tracking-widest text-muted uppercase">Salons</p>
            <button
              onClick={() => setDialog("channel")}
              disabled={!activeServer}
              className="text-sm text-muted transition hover:text-white disabled:opacity-40"
              title="Nouveau salon"
            >
              +
            </button>
          </div>
          {activeServer?.channels.map((channel) => (
            <button
              key={channel.id}
              onClick={() => setActiveChannelId(channel.id)}
              className={`flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-[13.5px] transition ${
                activeChannelId === channel.id
                  ? "bg-white/10 font-bold text-white"
                  : "text-muted hover:bg-white/5 hover:text-white"
              }`}
            >
              <span className="text-muted">#</span>
              <span className="truncate">{channel.name}</span>
            </button>
          ))}

          <div className="mt-4 flex items-center justify-between px-2 pb-1.5">
            <p className="text-[10px] font-bold tracking-widest text-muted uppercase">Serveurs</p>
            <button
              onClick={() => setDialog("discover")}
              className="text-[11px] font-semibold text-brand-soft hover:underline"
            >
              Découvrir
            </button>
          </div>
          {servers.map((server) => (
            <button
              key={server.id}
              onClick={() => setActiveServerId(server.id)}
              className={`flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-[13px] transition ${
                activeServerId === server.id
                  ? "bg-white/[0.07] font-bold"
                  : "text-muted hover:bg-white/5 hover:text-white"
              }`}
            >
              <span>{server.emoji}</span>
              <span className="truncate">{server.name}</span>
              {server.onlineCount > 0 ? (
                <span className="ml-auto h-1.5 w-1.5 rounded-full bg-mint" />
              ) : null}
            </button>
          ))}
          <button
            onClick={() => setDialog("server")}
            className="mt-2 flex w-full items-center gap-2 rounded-lg border border-dashed border-white/15 px-2.5 py-2 text-left text-[13px] text-muted transition hover:border-brand/50 hover:text-white"
          >
            <span>✨</span> Créer un serveur
          </button>
        </div>

        <div className="border-t border-line/60 p-3">
          <button
            onClick={() => setDialog("account")}
            className="flex w-full items-center gap-2.5 rounded-xl px-1.5 py-1.5 transition hover:bg-white/5"
          >
            <Avatar name={user.displayName} seed={user.id} size="sm" online />
            <div className="min-w-0 flex-1 text-left">
              <p className="truncate text-[13px] font-bold">{user.displayName}</p>
              <p className="truncate text-[10.5px] text-muted">@{user.username}</p>
            </div>
            <span className="text-muted">⚙️</span>
          </button>
        </div>
      </aside>

      {/* Zone principale */}
      <main className="relative flex min-h-0 min-w-0 flex-1 flex-col">
        <header className="border-b border-line/60 bg-panel/30 backdrop-blur">
          <div className="flex items-center gap-2 px-3 py-2.5 sm:px-4">
            <button
              onClick={() => setDialog("nav")}
              className="flex shrink-0 items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-2.5 py-1.5 transition active:scale-95 md:hidden"
            >
              <span className="text-lg">{headerEmoji}</span>
              <span className="max-w-[80px] truncate text-[11px] font-bold">{headerName}</span>
              <span className="text-[9px] text-muted">▾</span>
            </button>
            <div className="min-w-0 flex-1">
              <h1 className="truncate text-[14px] font-black tracking-tight">
                <span className="text-muted"># </span>
                {activeChannel?.name ?? "salon"}
              </h1>
              <p className="flex items-center gap-1.5 text-[10.5px] text-muted">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-mint" />
                {onlineCount} en ligne
                <span className="truncate">· {activeServer?.name ?? "Poto"}</span>
              </p>
            </div>
            <button
              onClick={() => setDialog("invite")}
              className="grid h-9 w-9 place-items-center rounded-xl border border-white/10 bg-white/5 text-sm transition hover:bg-white/10 active:scale-95"
              title="Inviter des potes"
            >
              🎟️
            </button>
            <button
              onClick={() => setDialog("members")}
              className="grid h-9 w-9 place-items-center rounded-xl border border-white/10 bg-white/5 text-sm transition hover:bg-white/10 active:scale-95 xl:hidden"
              title="Membres"
            >
              👥
            </button>
          </div>

          <div className="no-scrollbar flex items-center gap-1.5 overflow-x-auto px-3 pb-2.5 md:hidden">
            {activeServer?.channels.map((channel) => (
              <button
                key={channel.id}
                onClick={() => setActiveChannelId(channel.id)}
                className={`shrink-0 rounded-full px-3 py-1.5 text-[12px] font-semibold transition ${
                  activeChannelId === channel.id
                    ? "bg-white text-ink"
                    : "border border-white/10 bg-white/5 text-muted"
                }`}
              >
                # {channel.name}
              </button>
            ))}
            {activeServer ? (
              <button
                onClick={() => setDialog("channel")}
                className="grid h-7 w-7 shrink-0 place-items-center rounded-full border border-dashed border-white/20 text-muted"
                title="Nouveau salon"
              >
                +
              </button>
            ) : null}
          </div>
        </header>

        <div
          ref={scrollRef}
          onScroll={handleScroll}
          className="no-scrollbar min-h-0 flex-1 overflow-y-auto"
        >
          {!ready ? (
            <div className="flex h-full items-center justify-center">
              <span className="h-6 w-6 animate-spin rounded-full border-2 border-brand/40 border-t-brand" />
            </div>
          ) : serversWithoutActive ? (
            <div className="flex h-full items-center justify-center">
              <EmptyState
                emoji="🚀"
                title="Bienvenue sur Poto !"
                text="Crée ton premier serveur et invite tes potes, ou rejoins le serveur public avec le code POTO."
              >
                <button className={primaryButton} onClick={() => setDialog("server")}>
                  ✨ Créer mon serveur
                </button>
                <button className={ghostButton} onClick={() => setDialog("join")}>
                  🎟️ J&apos;ai un code d&apos;invitation
                </button>
                <button className={ghostButton} onClick={() => setDialog("discover")}>
                  🧭 Découvrir les serveurs publics
                </button>
              </EmptyState>
            </div>
          ) : (
            renderMessages()
          )}
        </div>

        <div className="border-t border-line/60 bg-panel/60 px-3 pt-2 safe-bottom sm:px-4">
          <form onSubmit={sendMessage} className="flex items-end gap-2">
            <div className="flex flex-1 items-end gap-2 rounded-2xl border border-line bg-panel-2 px-3 py-2 transition focus-within:border-brand/60">
              <span className="pb-1 text-base opacity-70">💬</span>
              <textarea
                value={draft}
                onChange={(event) => setDraft(event.target.value.slice(0, 2000))}
                onKeyDown={(event) => {
                  if (event.key === "Enter" && !event.shiftKey) {
                    event.preventDefault();
                    void sendMessage();
                  }
                }}
                rows={1}
                maxLength={2000}
                placeholder={
                  activeChannelId
                    ? `Écrire dans #${activeChannel?.name ?? "général"}…`
                    : "Choisis un salon pour écrire…"
                }
                disabled={!activeChannelId || serversWithoutActive}
                className="max-h-32 min-h-[24px] flex-1 resize-none bg-transparent py-1 text-[15px] leading-snug outline-none placeholder:text-muted/60 disabled:opacity-50"
              />
              <span className="pb-1 text-[10px] text-muted/60">{draft.length}/2000</span>
            </div>
            <button
              type="submit"
              disabled={!draft.trim() || sending || !activeChannelId}
              className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-brand to-pink text-lg font-black shadow-lg shadow-brand/25 transition active:scale-95 disabled:opacity-40"
              aria-label="Envoyer"
            >
              ↑
            </button>
          </form>
          <p className="mt-1.5 pb-1 text-center text-[10px] text-muted/60">
            Entrée pour envoyer · tes potes reçoivent en direct
          </p>
        </div>
      </main>

      {/* Membres (desktop) */}
      <aside className="hidden w-[232px] shrink-0 flex-col border-l border-line/60 bg-panel/25 xl:flex">
        <div className="border-b border-line/60 px-4 py-3.5">
          <p className="text-[10px] font-bold tracking-widest text-muted uppercase">Serveur</p>
          <p className="mt-1 truncate text-sm font-black">
            {activeServer?.emoji} {activeServer?.name ?? "—"}
          </p>
          {activeServer?.description ? (
            <p className="mt-1 line-clamp-2 text-[11px] leading-relaxed text-muted">
              {activeServer.description}
            </p>
          ) : null}
          <button
            onClick={() => setDialog("invite")}
            className="mt-3 w-full rounded-lg border border-white/10 bg-white/5 px-2 py-2 text-[11px] font-bold text-lemon transition hover:bg-white/10"
          >
            Code : {activeServer?.inviteCode ?? "—"}
          </button>
        </div>
        <div className="no-scrollbar flex-1 overflow-y-auto px-2 py-3">
          <p className="px-2 pb-1.5 text-[10px] font-bold tracking-widest text-muted uppercase">
            En ligne — {membersOnline.length}
          </p>
          {membersOnline.map((member) => (
            <MemberRow key={member.id} member={member} />
          ))}
          {membersOffline.length > 0 ? (
            <>
              <p className="mt-4 px-2 pb-1.5 text-[10px] font-bold tracking-widest text-muted uppercase">
                Hors ligne — {membersOffline.length}
              </p>
              {membersOffline.map((member) => (
                <MemberRow key={member.id} member={member} />
              ))}
            </>
          ) : null}
        </div>
      </aside>

      {/* ---------- Feuilles / modales ---------- */}

      <Sheet
        open={dialog === "nav"}
        onClose={() => setDialog(null)}
        title={activeServer ? `${activeServer.emoji} ${activeServer.name}` : "Tes serveurs"}
        subtitle={
          activeServer
            ? `${activeServer.memberCount} membres · code ${activeServer.inviteCode}`
            : "Crée ou rejoins un serveur pour discuter."
        }
      >
        <div className="space-y-5">
          <div>
            <p className="mb-1.5 text-[10px] font-bold tracking-widest text-muted uppercase">
              Salons
            </p>
            <div className="space-y-1">
              {activeServer?.channels.map((channel) => (
                <button
                  key={channel.id}
                  onClick={() => {
                    setActiveChannelId(channel.id);
                    setDialog(null);
                  }}
                  className={`flex w-full items-center gap-2 rounded-xl px-3 py-2.5 text-left text-sm transition ${
                    activeChannelId === channel.id
                      ? "bg-white/10 font-bold"
                      : "bg-white/[0.03] text-muted"
                  }`}
                >
                  <span className="text-muted">#</span>
                  {channel.name}
                  {activeChannelId === channel.id ? (
                    <span className="ml-auto h-1.5 w-1.5 rounded-full bg-mint" />
                  ) : null}
                </button>
              ))}
              <button
                onClick={() => setDialog("channel")}
                className="w-full rounded-xl border border-dashed border-white/15 px-3 py-2.5 text-left text-sm text-muted"
              >
                + Créer un salon
              </button>
            </div>
          </div>

          <div>
            <p className="mb-1.5 text-[10px] font-bold tracking-widest text-muted uppercase">
              Tes serveurs
            </p>
            <div className="space-y-1">
              {servers.map((server) => (
                <button
                  key={server.id}
                  onClick={() => {
                    setActiveServerId(server.id);
                    setDialog(null);
                  }}
                  className={`flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-left text-sm transition ${
                    activeServerId === server.id
                      ? "bg-white/10 font-bold"
                      : "bg-white/[0.03] text-muted"
                  }`}
                >
                  <span className="text-base">{server.emoji}</span>
                  <span className="min-w-0 flex-1 truncate">{server.name}</span>
                  <span className="text-[10px] text-muted">{server.onlineCount} en ligne</span>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              className={primaryButton}
              onClick={() => {
                setDialog("server");
              }}
            >
              ✨ Créer
            </button>
            <button className={ghostButton} onClick={() => setDialog("join")}>
              🎟️ Rejoindre
            </button>
            <button
              className={`${ghostButton} col-span-2`}
              onClick={() => setDialog("discover")}
            >
              🧭 Découvrir les serveurs publics
            </button>
          </div>

          <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-3">
            <Avatar name={user.displayName} seed={user.id} size="sm" online />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-bold">{user.displayName}</p>
              <p className="truncate text-[11px] text-muted">@{user.username}</p>
            </div>
            <button
              onClick={() => setDialog("account")}
              className="rounded-lg bg-white/5 px-2.5 py-1.5 text-[11px] font-semibold"
            >
              Compte
            </button>
          </div>
        </div>
      </Sheet>

      <Sheet
        open={dialog === "server"}
        onClose={() => setDialog(null)}
        title="Créer un serveur"
        subtitle="Un espace privé pour ton groupe. Tu pourras inviter tes potes juste après."
      >
        <form onSubmit={createServer} className="space-y-4">
          <label className="block">
            <span className="mb-1.5 block text-[10px] font-bold tracking-widest text-muted uppercase">
              Nom du serveur
            </span>
            <input
              value={serverName}
              onChange={(event) => setServerName(event.target.value.slice(0, 40))}
              placeholder="Ex : Les potes du lycée"
              maxLength={40}
              required
              className={inputClass}
            />
          </label>

          <div>
            <span className="mb-1.5 block text-[10px] font-bold tracking-widest text-muted uppercase">
              Emoji
            </span>
            <div className="grid grid-cols-6 gap-1.5">
              {SERVER_EMOJIS.map((emoji) => (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => setServerEmoji(emoji)}
                  className={`grid aspect-square place-items-center rounded-xl text-xl transition ${
                    serverEmoji === emoji
                      ? "bg-brand/30 ring-2 ring-brand"
                      : "bg-white/5 hover:bg-white/10"
                  }`}
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>

          <label className="block">
            <span className="mb-1.5 block text-[10px] font-bold tracking-widest text-muted uppercase">
              Description (optionnel)
            </span>
            <input
              value={serverDesc}
              onChange={(event) => setServerDesc(event.target.value.slice(0, 160))}
              placeholder="Le QG de la bande, tous les soirs"
              className={inputClass}
            />
          </label>

          <label className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-3">
            <input
              type="checkbox"
              checked={serverPublic}
              onChange={(event) => setServerPublic(event.target.checked)}
              className="h-4 w-4 accent-[#7c5cff]"
            />
            <span className="text-xs leading-relaxed text-muted">
              Serveur public — visible dans « Découvrir » pour rencontrer du monde.
            </span>
          </label>

          <button type="submit" disabled={busy} className={`${primaryButton} w-full`}>
            {busy ? "Création…" : "Créer le serveur →"}
          </button>
        </form>
      </Sheet>

      <Sheet
        open={dialog === "join"}
        onClose={() => setDialog(null)}
        title="Rejoindre un serveur"
        subtitle="Entre le code à 6 caractères que ton pote t'a envoyé."
      >
        <form
          onSubmit={(event) => {
            event.preventDefault();
            void joinByCode(joinCode);
          }}
          className="space-y-4"
        >
          <input
            value={joinCode}
            onChange={(event) =>
              setJoinCode(
                event.target.value
                  .toUpperCase()
                  .replace(/[^A-Z0-9]/g, "")
                  .slice(0, 12),
              )
            }
            placeholder="EX : POTO"
            autoCapitalize="characters"
            autoCorrect="off"
            spellCheck={false}
            className={`${inputClass} text-center font-mono text-2xl font-black tracking-[0.35em]`}
          />
          <button type="submit" disabled={busy || joinCode.length < 4} className={`${primaryButton} w-full`}>
            {busy ? "Connexion…" : "Rejoindre →"}
          </button>
          <button
            type="button"
            onClick={() => void joinByCode("POTO")}
            className={`${ghostButton} w-full`}
            disabled={busy}
          >
            🔥 Essayer le serveur public (code POTO)
          </button>
        </form>
      </Sheet>

      <Sheet
        open={dialog === "discover"}
        onClose={() => setDialog(null)}
        title="Serveurs publics"
        subtitle="Des groupes ouverts à tous, avec de vrais salons."
      >
        {discoverLoading ? (
          <div className="space-y-2">
            {[0, 1, 2].map((row) => (
              <div key={row} className="h-20 animate-pulse rounded-2xl bg-white/5" />
            ))}
          </div>
        ) : discoverList.length === 0 ? (
          <EmptyState
            emoji="🧭"
            title="Personne à l'horizon"
            text="Aucun serveur public pour l'instant. Crée le premier !"
          >
            <button className={primaryButton} onClick={() => setDialog("server")}>
              ✨ Créer un serveur
            </button>
          </EmptyState>
        ) : (
          <div className="space-y-2">
            {discoverList.map((server) => (
              <div
                key={server.id}
                className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-3"
              >
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-white/5 text-xl">
                  {server.emoji}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-bold">{server.name}</p>
                  <p className="truncate text-[11px] text-muted">
                    {server.memberCount} membres · {server.onlineCount} en ligne
                  </p>
                  {server.description ? (
                    <p className="mt-0.5 line-clamp-1 text-[11px] text-muted/80">
                      {server.description}
                    </p>
                  ) : null}
                </div>
                <button
                  onClick={() => void joinByCode(server.inviteCode)}
                  disabled={busy}
                  className="shrink-0 rounded-xl bg-white px-3 py-2 text-[11px] font-bold text-ink disabled:opacity-50"
                >
                  {server.joined ? "Ouvrir" : "Rejoindre"}
                </button>
              </div>
            ))}
          </div>
        )}
      </Sheet>

      <Sheet
        open={dialog === "invite"}
        onClose={() => setDialog(null)}
        title="Inviter tes potes"
        subtitle="Envoie ce code (ou le lien) : ils rejoignent le serveur en un clic."
      >
        {activeServer ? (
          <div className="space-y-4">
            <div className="rounded-2xl border border-brand/30 bg-gradient-to-br from-brand/20 to-pink/10 p-5 text-center">
              <p className="text-[10px] font-bold tracking-[0.25em] text-muted uppercase">
                Code d&apos;invitation
              </p>
              <p className="mt-1 font-mono text-4xl font-black tracking-[0.3em] text-lemon">
                {activeServer.inviteCode}
              </p>
              <p className="mt-2 text-[11px] text-muted">
                {activeServer.emoji} {activeServer.name} · {activeServer.memberCount} membres
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                className={primaryButton}
                onClick={() => void copyText(activeServer.inviteCode, "Code copié !")}
              >
                Copier le code
              </button>
              <button className={ghostButton} onClick={() => void shareInvite()}>
                Partager le lien
              </button>
            </div>

            <CopyField
              value={inviteLink(activeServer.inviteCode)}
              label="Lien d'invitation"
              onCopy={() =>
                void copyText(inviteLink(activeServer.inviteCode), "Lien copié !")
              }
            />

            {activeServer.role === "owner" ? (
              <button
                onClick={() => void regenerateCode()}
                disabled={busy}
                className="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-[12px] font-semibold text-muted transition hover:text-white disabled:opacity-50"
              >
                ♻️ Générer un nouveau code (l&apos;ancien sera désactivé)
              </button>
            ) : null}

            <p className="text-center text-[11px] leading-relaxed text-muted">
              Toute personne avec ce code peut entrer et lire les salons. Ne le partage qu&apos;avec
              des gens de confiance.
            </p>
          </div>
        ) : (
          <EmptyState emoji="🎟️" title="Aucun serveur" text="Crée d'abord un serveur." />
        )}
      </Sheet>

      <Sheet
        open={dialog === "channel"}
        onClose={() => setDialog(null)}
        title="Nouveau salon"
        subtitle={`Dans ${activeServer?.name ?? "ton serveur"} — parfait pour un thème précis.`}
      >
        <form onSubmit={createChannel} className="space-y-4">
          <div className="flex items-center gap-2 rounded-xl border border-line bg-panel-2 px-3">
            <span className="text-muted">#</span>
            <input
              value={channelName}
              onChange={(event) => setChannelName(event.target.value.slice(0, 24))}
              placeholder="memes"
              maxLength={24}
              required
              className="w-full bg-transparent py-3 text-[15px] outline-none placeholder:text-muted/60"
            />
          </div>
          <div className="flex flex-wrap gap-1.5">
            {["général", "memes", "musique", "foot", "jeux", "entraide"].map((suggestion) => (
              <button
                key={suggestion}
                type="button"
                onClick={() => setChannelName(suggestion)}
                className="rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] text-muted transition hover:text-white"
              >
                #{suggestion}
              </button>
            ))}
          </div>
          <button type="submit" disabled={busy} className={`${primaryButton} w-full`}>
            {busy ? "Création…" : "Créer le salon →"}
          </button>
        </form>
      </Sheet>

      <Sheet
        open={dialog === "members"}
        onClose={() => setDialog(null)}
        title={activeServer ? `Membres de ${activeServer.name}` : "Membres"}
        subtitle={`${members.length} membres · ${onlineCount} en ligne`}
      >
        <div className="space-y-4">
          <div className="space-y-1">
            {membersOnline.length === 0 ? (
              <p className="rounded-xl bg-white/5 px-3 py-3 text-xs text-muted">
                Personne en ligne pour l&apos;instant. Invite tes potes !
              </p>
            ) : null}
            {membersOnline.map((member) => (
              <MemberRow key={member.id} member={member} size="md" />
            ))}
          </div>
          {membersOffline.length > 0 ? (
            <div>
              <p className="mb-1.5 text-[10px] font-bold tracking-widest text-muted uppercase">
                Hors ligne
              </p>
              <div className="space-y-1 opacity-70">
                {membersOffline.map((member) => (
                  <MemberRow key={member.id} member={member} size="md" />
                ))}
              </div>
            </div>
          ) : null}
          <div className="flex flex-col gap-2">
            <button className={ghostButton} onClick={() => setDialog("invite")}>
              🎟️ Inviter quelqu&apos;un
            </button>
            {activeServer && activeServer.role !== "owner" ? (
              <button
                className="w-full rounded-xl border border-pink/30 bg-pink/10 px-4 py-3 text-sm font-semibold text-pink"
                onClick={() => void leaveServer()}
              >
                Quitter ce serveur
              </button>
            ) : null}
          </div>
        </div>
      </Sheet>

      <Sheet
        open={dialog === "account"}
        onClose={() => setDialog(null)}
        title="Mon compte"
        subtitle="Tes infos Poto et les réglages rapides."
      >
        <div className="space-y-5">
          <div className="flex items-center gap-3.5 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <Avatar name={user.displayName} seed={user.id} size="lg" online />
            <div className="min-w-0">
              <p className="truncate text-lg font-black">{user.displayName}</p>
              <p className="truncate text-sm text-muted">@{user.username}</p>
              <p className="mt-1 inline-flex items-center gap-1 rounded-full bg-mint/15 px-2 py-0.5 text-[10px] font-bold text-mint">
                ● En ligne
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="rounded-xl bg-white/5 p-3">
              <p className="text-xl font-black">{servers.length}</p>
              <p className="text-[10px] text-muted">serveurs</p>
            </div>
            <div className="rounded-xl bg-white/5 p-3">
              <p className="text-xl font-black">{activeServer?.memberCount ?? 0}</p>
              <p className="text-[10px] text-muted">membres ici</p>
            </div>
          </div>

          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <p className="text-xs font-bold">📲 Installer Poto sur ton téléphone</p>
            <p className="mt-1 text-[11px] leading-relaxed text-muted">
              Safari : bouton Partager → « Sur l&apos;écran d&apos;accueil ». Chrome : menu ⋮ →
              « Installer l&apos;application ». Tu auras une icône comme une vraie app.
            </p>
          </div>

          <div className="flex flex-col gap-2">
            <button className={ghostButton} onClick={() => setDialog("invite")}>
              🎟️ Inviter des potes
            </button>
            <Link href="/" className={ghostButton}>
              🌐 Retour au site
            </Link>
            <button
              onClick={() => void logout()}
              disabled={busy}
              className="w-full rounded-xl border border-pink/30 bg-pink/10 px-4 py-3 text-sm font-bold text-pink transition hover:bg-pink/20 disabled:opacity-50"
            >
              Se déconnecter
            </button>
          </div>
        </div>
      </Sheet>

      {toast ? (
        <div className="pointer-events-none fixed inset-x-0 bottom-24 z-[60] flex justify-center px-4 md:bottom-8">
          <div
            className={`animate-pop rounded-2xl border px-4 py-3 text-sm font-semibold shadow-xl backdrop-blur ${
              toast.type === "success"
                ? "border-mint/30 bg-[#0d2b22]/95 text-mint"
                : "border-pink/30 bg-[#2b0d1a]/95 text-pink"
            }`}
          >
            {toast.text}
          </div>
        </div>
      ) : null}
    </div>
  );
}

function MemberRow({ member, size = "sm" }: { member: MemberDTO; size?: "sm" | "md" }) {
  return (
    <div className="flex items-center gap-2.5 rounded-xl px-2.5 py-2 transition hover:bg-white/5">
      <Avatar name={member.displayName} seed={member.id} size={size} online={member.online} />
      <div className="min-w-0 flex-1">
        <p className="flex items-center gap-1.5 truncate text-[13px] font-semibold">
          {member.displayName}
          {member.role === "owner" ? (
            <span className="rounded bg-lemon/20 px-1 py-px text-[8px] font-black tracking-wider text-lemon uppercase">
              owner
            </span>
          ) : null}
        </p>
        <p className="truncate text-[10.5px] text-muted">
          @{member.username} · {member.online ? "en ligne" : "hors ligne"}
        </p>
      </div>
    </div>
  );
}
