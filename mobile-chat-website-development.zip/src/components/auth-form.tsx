"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";

type Props = {
  mode: "login" | "register";
  redirectTo: string;
  presetInvite?: string;
};

export function AuthForm({ mode, redirectTo, presetInvite }: Props) {
  const router = useRouter();
  const [displayName, setDisplayName] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const isRegister = mode === "register";

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const response = await fetch(isRegister ? "/api/auth/register" : "/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(
          isRegister ? { displayName, username, password } : { username, password },
        ),
      });

      const data = (await response.json().catch(() => ({}))) as { error?: string };

      if (!response.ok) {
        setError(data.error ?? "Une erreur est survenue. Réessaie.");
        setLoading(false);
        return;
      }

      router.replace(redirectTo);
      router.refresh();
    } catch {
      setError("Connexion impossible. Vérifie ta connexion internet.");
      setLoading(false);
    }
  }

  return (
    <div className="w-full">
      <div className="mb-7">
        <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] font-semibold text-muted">
          {isRegister ? "🎉 Nouveau compte · gratuit" : "👋 Content de te revoir"}
        </span>
        <h1 className="mt-4 text-3xl font-black tracking-tight sm:text-4xl">
          {isRegister ? "Bienvenue sur Poto" : "Reconnexion"}
        </h1>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          {isRegister
            ? "Choisis ton nom, ton @pseudo et c'est parti. On t'offre même un premier serveur."
            : "Entre ton @pseudo et ton mot de passe pour retrouver tes salons."}
        </p>
      </div>

      {presetInvite ? (
        <div className="mb-5 rounded-2xl border border-lemon/25 bg-lemon/10 px-4 py-3 text-sm">
          🎟️ Invitation pour le serveur{" "}
          <span className="font-black tracking-widest text-lemon">{presetInvite.toUpperCase()}</span>{" "}
          — tu rejoindras automatiquement après {isRegister ? "inscription" : "connexion"}.
        </div>
      ) : null}

      <form onSubmit={handleSubmit} className="space-y-4">
        {isRegister ? (
          <label className="block">
            <span className="mb-1.5 block text-xs font-bold tracking-wide text-muted uppercase">
              Ton nom (visible par les potes)
            </span>
            <input
              value={displayName}
              onChange={(event) => setDisplayName(event.target.value)}
              placeholder="Ex : Marie"
              autoComplete="name"
              maxLength={32}
              required
              className="w-full rounded-2xl border border-line bg-panel-2 px-4 py-3.5 text-base outline-none transition placeholder:text-muted/60 focus:border-brand focus:ring-2 focus:ring-brand/30"
            />
          </label>
        ) : null}

        <label className="block">
          <span className="mb-1.5 block text-xs font-bold tracking-wide text-muted uppercase">
            @pseudo
          </span>
          <div className="flex items-center rounded-2xl border border-line bg-panel-2 px-4 transition focus-within:border-brand focus-within:ring-2 focus-within:ring-brand/30">
            <span className="text-muted">@</span>
            <input
              value={username}
              onChange={(event) => setUsername(event.target.value.replace(/\s/g, ""))}
              placeholder="marie29"
              autoComplete="username"
              autoCapitalize="none"
              spellCheck={false}
              maxLength={20}
              required
              className="w-full bg-transparent px-1.5 py-3.5 text-base outline-none placeholder:text-muted/60"
            />
          </div>
        </label>

        <label className="block">
          <span className="mb-1.5 block text-xs font-bold tracking-wide text-muted uppercase">
            Mot de passe
          </span>
          <div className="flex items-center rounded-2xl border border-line bg-panel-2 px-4 transition focus-within:border-brand focus-within:ring-2 focus-within:ring-brand/30">
            <input
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              type={showPassword ? "text" : "password"}
              placeholder={isRegister ? "6 caractères minimum" : "Ton mot de passe"}
              autoComplete={isRegister ? "new-password" : "current-password"}
              minLength={6}
              required
              className="w-full bg-transparent py-3.5 text-base outline-none placeholder:text-muted/60"
            />
            <button
              type="button"
              onClick={() => setShowPassword((value) => !value)}
              className="ml-2 text-xs font-semibold text-muted transition hover:text-white"
            >
              {showPassword ? "Cacher" : "Voir"}
            </button>
          </div>
        </label>

        {error ? (
          <p className="rounded-2xl border border-pink/30 bg-pink/10 px-4 py-3 text-sm text-pink">
            {error}
          </p>
        ) : null}

        <button
          type="submit"
          disabled={loading}
          className="mt-2 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-brand to-pink px-5 py-4 text-base font-bold shadow-lg shadow-brand/25 transition hover:brightness-110 disabled:opacity-60"
        >
          {loading ? (
            <>
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" />
              Un instant…
            </>
          ) : isRegister ? (
            "Créer mon compte →"
          ) : (
            "Entrer dans mes salons →"
          )}
        </button>
      </form>

      <p className="mt-6 text-center text-sm text-muted">
        {isRegister ? "Déjà un compte ?" : "Pas encore de compte ?"}{" "}
        <Link
          href={
            isRegister
              ? presetInvite
                ? `/connexion?invite=${presetInvite}`
                : "/connexion"
              : presetInvite
                ? `/inscription?invite=${presetInvite}`
                : "/inscription"
          }
          className="font-bold text-brand-soft underline-offset-4 hover:underline"
        >
          {isRegister ? "Connecte-toi" : "Inscris-toi gratuitement"}
        </Link>
      </p>

      <p className="mt-8 text-center text-[11px] leading-relaxed text-muted/70">
        En continuant, tu acceptes la règle d&apos;or de Poto : rester sympa avec ses potes.
        Mot de passe chiffré, aucune revente de données.
      </p>
    </div>
  );
}
